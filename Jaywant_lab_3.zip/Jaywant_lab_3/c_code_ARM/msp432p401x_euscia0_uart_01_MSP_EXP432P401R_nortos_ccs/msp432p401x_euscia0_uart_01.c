/* ************************************************************************************************************************** */
/*                                  Author Name: Aaksha Jaywant                                                               */
/*                                 Course: Embedded System Design                                                             */
/*                                    Assignment: Lab 3 Part 2                                                                */
/*        Leveraged Code: https://www.geeksforgeeks.org/implement-itoa/                                                       */
/*                        https://www.geeksforgeeks.org/convert-floating-point-number-string/                                 */
/*                                                                                                                            */
/* ************************************************************************************************************************** */


/*
 *                       MSP432 CODE EXAMPLE DISCLAIMER
 *
 * MSP432 code examples are self-contained low-level programs that typically
 * demonstrate a single peripheral function or device feature in a highly
 * concise manner. For this the code may rely on the device's power-on default
 * register values and settings such as the clock configuration and care must
 * be taken when combining code from several examples to avoid potential side
 * effects. Also see http://www.ti.com/tool/mspdriverlib for an API functional
 * library & https://dev.ti.com/pinmux/ for a GUI approach to peripheral configuration.
 *
 * --/
******************************************************************************
   MSP432P401 Demo - eUSCI_A0 UART echo at 9600 baud using BRCLK = 12MHz

  Description: This demo echoes back characters received via a PC serial port.
  SMCLK/ DCO is used as a clock source and the device is put in LPM0
  The auto-clock enable feature is used by the eUSCI and SMCLK is turned off
  when the UART is idle and turned on when a receive edge is detected.
  Note that level shifter hardware is needed to shift between RS232 and MSP
  voltage levels.

  The example code shows proper initialization of registers
  and interrupts to receive and transmit data.

                MSP432P401
             -----------------
         /|\|                 |
          | |                 |
          --|RST              |
            |                 |
            |                 |
            |     P1.3/UCA0TXD|----> PC (echo)
            |     P1.2/UCA0RXD|<---- PC
            |                 |

   William Goh
   Texas Instruments Inc.
   June 2016 (updated) | June 2014 (created)
   Built with CCSv6.1, IAR, Keil, GCC
****************************************************************************** */
/************************HEADER FILES *************************/
#include "ti/devices/msp432p4xx/inc/msp.h"
/* DriverLib Includes */
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include <stdint.h>
#include <stdbool.h>
//#include <stdint.h>
#include <math.h>
#include <string.h>

/******* variables for temp*******/
uint32_t cal30;
uint32_t cal85;
float calDifference;
float tempC;
float tempF;
float tempK;
/********************************/

int plus_count=40;
int minus_count;
int value_i_temp;
int led_count;
void ftoa(float n, char *res, int afterpoint);
int intToStr(int x, char str[], int d);
void reverse(char *str, int len);

Timer_A_PWMConfig pwmConfig =
{
        TIMER_A_CLOCKSOURCE_SMCLK,
        TIMER_A_CLOCKSOURCE_DIVIDER_1,
        32000,
        TIMER_A_CAPTURECOMPARE_REGISTER_1,
        TIMER_A_OUTPUTMODE_RESET_SET,
        12800
};


int main(void)
{
    WDT_A->CTL = WDT_A_CTL_PW |             // Stop watchdog timer
            WDT_A_CTL_HOLD;


 /******************************** Toggle switch to generate PWM **************************************************/

           EUSCI_A0->CTLW0 |= EUSCI_A_CTLW0_SWRST; // Put eUSCI in reset
           EUSCI_A0->CTLW0 = EUSCI_A_CTLW0_SWRST | // Remain eUSCI in reset
           EUSCI_B_CTLW0_SSEL__SMCLK;      // Configure eUSCI clock source for SMCLK
       //![Simple Timer_A Example]
       /* Setting MCLK to REFO at 128Khz for LF mode
        * Setting SMCLK to 64Khz */
          EUSCI_A0->BRW = 78;                     // 12000000/16/9600
          EUSCI_A0->MCTLW = (2 << EUSCI_A_MCTLW_BRF_OFS) |
          EUSCI_A_MCTLW_OS16;

          EUSCI_A0->CTLW0 &= ~EUSCI_A_CTLW0_SWRST; // Initialize eUSCI
          EUSCI_A0->IFG &= ~EUSCI_A_IFG_RXIFG;    // Clear eUSCI RX interrupt flag
          EUSCI_A0->IE |= EUSCI_A_IE_RXIE;        // Enable USCI_A0 RX interrupt

             MAP_CS_setReferenceOscillatorFrequency(CS_REFO_128KHZ);
             MAP_CS_initClockSignal(CS_MCLK, CS_REFOCLK_SELECT, CS_CLOCK_DIVIDER_1);
             MAP_CS_initClockSignal(CS_SMCLK, CS_REFOCLK_SELECT, CS_CLOCK_DIVIDER_2);
             MAP_PCM_setPowerState(PCM_AM_LF_VCORE0);

             /* Configuring GPIO2.4 as peripheral output for PWM  and P1.1 for button
              * interrupt */
             MAP_GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P2, GPIO_PIN4,
             GPIO_PRIMARY_MODULE_FUNCTION);
             MAP_GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1, GPIO_PIN1);
             MAP_GPIO_clearInterruptFlag(GPIO_PORT_P1, GPIO_PIN1);
             MAP_GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN1);

             /* P1.4 for button
                 * interrupt */
                //MAP_GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P2, GPIO_PIN4,
                        //GPIO_PRIMARY_MODULE_FUNCTION);
                MAP_GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1, GPIO_PIN4);
                MAP_GPIO_clearInterruptFlag(GPIO_PORT_P1, GPIO_PIN4);
                MAP_GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN4);

             /* Configuring Timer_A to have a period of approximately 500ms and
              * an initial duty cycle of 40% of that (3200 ticks)  */
             MAP_Timer_A_generatePWM(TIMER_A0_BASE, &pwmConfig);
             //![Simple Timer_A Example]

             // Enabling interrupts
             MAP_Interrupt_enableInterrupt(INT_PORT1);

 /******************** Config UART for echoing of characters *************************************************/

             CS->KEY = CS_KEY_VAL;                   // Unlock CS module for register access
                CS->CTL0 = 0;                           // Reset tuning parameters
                CS->CTL0 = CS_CTL0_DCORSEL_3;           // Set DCO to 12MHz (nominal, center of 8-16MHz range)
                CS->CTL1 = CS_CTL1_SELA_2 |             // Select ACLK = REFO
                        CS_CTL1_SELS_3 |                // SMCLK = DCO
                        CS_CTL1_SELM_3;                 // MCLK = DCO
                CS->KEY = 0;                            // Lock CS module from unintended accesses

                // Configure UART pins
                P1->SEL0 |= BIT2 | BIT3;                // set 2-UART pin as secondary function

                // Configure UART
                EUSCI_A0->CTLW0 |= EUSCI_A_CTLW0_SWRST; // Put eUSCI in reset
                EUSCI_A0->CTLW0 = EUSCI_A_CTLW0_SWRST | // Remain eUSCI in reset
                        EUSCI_B_CTLW0_SSEL__SMCLK;      // Configure eUSCI clock source for SMCLK
                // Baud Rate calculation
                // 12000000/(16*9600) = 78.125
                // Fractional portion = 0.125
                // User's Guide Table 21-4: UCBRSx = 0x10
                // UCBRFx = int ( (78.125-78)*16) = 2
                EUSCI_A0->BRW = 78;                     // 12000000/16/9600
                EUSCI_A0->MCTLW = (2 << EUSCI_A_MCTLW_BRF_OFS) |
                        EUSCI_A_MCTLW_OS16;

                EUSCI_A0->CTLW0 &= ~EUSCI_A_CTLW0_SWRST; // Initialize eUSCI
                EUSCI_A0->IFG &= ~EUSCI_A_IFG_RXIFG;    // Clear eUSCI RX interrupt flag
                EUSCI_A0->IE |= EUSCI_A_IE_RXIE;        // Enable USCI_A0 RX interrupt


                // Enable eUSCIA0 interrupt in NVIC module
                NVIC->ISER[0] = 1 << ((EUSCIA0_IRQn) & 31);



/*************************************Temperature Sensor***********************************************/
               /* Enabling the FPU with stacking enabled (for use within ISR) */
                  FPU_enableModule();
                  FPU_enableLazyStacking();

                  /* Initializing ADC (MCLK/1/1) with temperature sensor routed */
                  ADC14_enableModule();
                  ADC14_initModule(ADC_CLOCKSOURCE_MCLK, ADC_PREDIVIDER_1, ADC_DIVIDER_1,
                          ADC_TEMPSENSEMAP);

                  /* Configuring ADC Memory (ADC_MEM0 A22 (Temperature Sensor) in repeat
                   * mode).
                   */
                  ADC14_configureSingleSampleMode(ADC_MEM0, true);
                  ADC14_configureConversionMemory(ADC_MEM0, ADC_VREFPOS_INTBUF_VREFNEG_VSS,
                          ADC_INPUT_A22, false);

                  /* Configuring the sample/hold time for 192 */
                  ADC14_setSampleHoldTime(ADC_PULSE_WIDTH_192,ADC_PULSE_WIDTH_192);

                  /* Enabling sample timer in auto iteration mode and interrupts*/
                  ADC14_enableSampleTimer(ADC_AUTOMATIC_ITERATION);
                  ADC14_enableInterrupt(ADC_INT0);

                  /* Setting reference voltage to 2.5 and enabling temperature sensor */
                  REF_A_enableTempSensor();
                  REF_A_setReferenceVoltage(REF_A_VREF2_5V);
                  REF_A_enableReferenceVoltage();

                  cal30 = SysCtl_getTempCalibrationConstant(SYSCTL_2_5V_REF,
                          SYSCTL_30_DEGREES_C);
                  cal85 = SysCtl_getTempCalibrationConstant(SYSCTL_2_5V_REF,
                          SYSCTL_85_DEGREES_C);
                  calDifference = cal85 - cal30;

                  /* Enabling Interrupts */
                  Interrupt_enableInterrupt(INT_ADC14);
                  Interrupt_enableMaster();

                  /* Triggering the start of the sample */
                  ADC14_enableConversion();
                  ADC14_toggleConversionTrigger();


                  __enable_irq();
                    while(1);



}



void PORT1_IRQHandler(void)
{
    int i=0;

      uint32_t status = MAP_GPIO_getEnabledInterruptStatus(GPIO_PORT_P1);
    MAP_GPIO_clearInterruptFlag(GPIO_PORT_P1, status);

// FOR INCREASING DUTY CYCLE

    if (status & GPIO_PIN1)
    {
        if(pwmConfig.dutyCycle == 28800)
        {
            pwmConfig.dutyCycle = 0;


      // var_name = _Timer_A_PWMConfig pwmConfig.dutyCycle;
        plus_count = 0;
        }
        else if(status & GPIO_PIN1)
        {
            pwmConfig.dutyCycle += 3200;
        plus_count+=10;

        /***********************************RGB***************************************************************************/
        if (plus_count == 50 || plus_count == 80 || plus_count == 10 )

                {
                    // Configure GPIO
                        P1->DIR |= BIT0;
                        P1->OUT |= BIT0;

                        P1->OUT ^= BIT0;

                        P2->DIR |= BIT1;
                        P2->OUT |= BIT1;
                        for(i=0;i<500;i++)
                        {
                         P2->OUT ^= BIT1;
                        }
                }

        if (plus_count == 60 ||  plus_count == 90 || plus_count == 20 )
        {
            P2->DIR |= BIT1;
            P2->OUT |= BIT1;

            P2->OUT ^= BIT1;

            P2->DIR |= BIT2;
            P2->OUT |= BIT2;
            for(i=0;i<500;i++)
            {
             P2->OUT ^= BIT2;
            }
        }

        if (plus_count == 70 || plus_count == 0 || plus_count == 30 )
                {
                    P2->DIR |= BIT2;
                    P2->OUT |= BIT2;
                    P2->OUT ^= BIT2;

                    P1->DIR |= BIT0;
                    P1->OUT |= BIT0;
                    for(i=0;i<500;i++)
                    {
                     P1->OUT ^= BIT0;
                    }
                }



        }
        MAP_Timer_A_generatePWM(TIMER_A0_BASE, &pwmConfig);
    }

//FOR DECREASING DUTY CYCLE

    else
    {
        if(pwmConfig.dutyCycle == 0)        //initially it was
        {
               pwmConfig.dutyCycle = 28800;
        plus_count = 90;
        }
         else if(status & GPIO_PIN4)
         {
               pwmConfig.dutyCycle -= 3200;

        plus_count-=10;

        /***********************************RGB***************************************************************************/
        if (plus_count == 30 || plus_count == 0 || plus_count == 70 )

                        {
                            // Configure GPIO
                                P1->DIR |= BIT0;
                                P1->OUT |= BIT0;

                                P1->OUT ^= BIT0;

                                P2->DIR |= BIT1;
                                P2->OUT |= BIT1;
                                for(i=0;i<500;i++)
                                {
                                 P2->OUT ^= BIT1;
                                }
                        }

                if (plus_count == 20 ||  plus_count == 90 || plus_count == 60 )
                {
                    P2->DIR |= BIT1;
                    P2->OUT |= BIT1;

                    P2->OUT ^= BIT1;

                    P2->DIR |= BIT2;
                    P2->OUT |= BIT2;
                    for(i=0;i<500;i++)
                    {
                     P2->OUT ^= BIT2;
                    }
                }

                if (plus_count == 10 || plus_count == 80 || plus_count == 50 )
                        {
                            P2->DIR |= BIT2;
                            P2->OUT |= BIT2;
                            P2->OUT ^= BIT2;

                            P1->DIR |= BIT0;
                            P1->OUT |= BIT0;
                            for(i=0;i<500;i++)
                            {
                             P1->OUT ^= BIT0;
                            }
                        }



         }
        MAP_Timer_A_generatePWM(TIMER_A0_BASE, &pwmConfig);
    }
    //var_name = pwmConfig.dutyCycle;






}

// UART interrupt service routine
void EUSCIA0_IRQHandler(void)
{
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\n';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\r';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF = EUSCI_A0->RXBUF;

//TO PRINT DUTY CYCLE ON PRESSING CHAR P
if(EUSCI_A0->RXBUF == 'P' || EUSCI_A0->RXBUF == 'p')
{
int var_ua;
char buff[3];
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= '\n';
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF = EUSCI_A0->RXBUF;
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= '\t';
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= 'D';
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= 'U';
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= 'T';
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= 'Y';
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= '\t';
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= 'C';
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= 'Y';
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= 'C';
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= 'L';
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= 'E';
       while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
       EUSCI_A0->TXBUF= '\t';

    var_ua = plus_count;

  /************************* ITOA FUNCTION *****************************************/

int i = 0;
char* str;
int base=10;
int rem=0;
str = buff;
                // Process individual digits
  while (var_ua != 0)
   {
    rem = var_ua % base;
    str[i++] = (rem > 9)? (rem-10) + 'a' : rem + '0';
    var_ua = var_ua/base;
   }

   str[i] = '\0'; // Append string terminator

int str_copy;
str_copy = i;
char temp;
   if(str_copy == 2)
    {
      temp = str[0];
      str[0] = str[1];
      str[1] = temp;

    }
    else if(str_copy == 3)
    {
     temp = str[1];
     str[1] = str[2];
     str[2] = temp;
    }


  /*******************************************************************************************/
int j=0;
 for(j=0;j<str_copy;j++)
  {
    while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
    EUSCI_A0->TXBUF= buff[j];
  }
    while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
    EUSCI_A0->TXBUF = '%';

}


//TO PRINT TEMPERATURE ON PRESSING CHAR T
else if (EUSCI_A0->RXBUF == 'T' || EUSCI_A0->RXBUF == 't')
{
   char res[9];
   char pes[9];
   char mes[9];

while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\n';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\r';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF = EUSCI_A0->RXBUF;
//while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
//EUSCI_A0->TXBUF= '\n';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';

//FOR CELSIUS
ftoa(tempC, res, 4);
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\n';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\r';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'T';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'E';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'M';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'P';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'I';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'N';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\n';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'C';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'E';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'L';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'S';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'I';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'U';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'S';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';

int j;
for(j=0;j<value_i_temp;j++)
  {
    while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
    EUSCI_A0->TXBUF= res[j];

  }

//FOR FAHRENHEIT
ftoa(tempF, pes, 4);
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\n';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\r';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'T';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'E';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'M';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'P';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'I';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'N';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\n';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'F';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'A';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'H';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'R';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'E';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'H';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'E';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'I';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'T';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';

for(j=0;j<value_i_temp;j++)
  {
    while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
    EUSCI_A0->TXBUF= pes[j];

  }

//FOR KELVIN
ftoa(tempK,mes,4);
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\n';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\r';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'T';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'E';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'M';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'P';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'I';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'N';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\n';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'K';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'E';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'L';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'V';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'I';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= 'N';
while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
EUSCI_A0->TXBUF= '\t';

for(j=0;j<value_i_temp;j++)
  {
    while(!(EUSCI_A0->IFG & EUSCI_A_IFG_TXIFG));
    EUSCI_A0->TXBUF= mes[j];

  }

}

//FOR INCREASING DUTY CYCLE USING + CHAR
else if(EUSCI_A0->RXBUF == '+')
{
    if(pwmConfig.dutyCycle == 28800)
      {
               pwmConfig.dutyCycle = 3200;
         // var_name = _Timer_A_PWMConfig pwmConfig.dutyCycle;
          // sym_count = 40;
           }
           else if(EUSCI_A0->RXBUF == '+')
           {
               pwmConfig.dutyCycle += 3200;
           //sym_count+=10;
           }
           MAP_Timer_A_generatePWM(TIMER_A0_BASE, &pwmConfig);
}

//FOR DECREASING DUTY CYCLE USING - CHAR
else if(EUSCI_A0->RXBUF == '-')
{
    if(pwmConfig.dutyCycle == 3200)        //initially it was
            {
                   pwmConfig.dutyCycle = 28800;
          //  sym_count = 40;
            }
             else if(EUSCI_A0->RXBUF == '-')
             {
                   pwmConfig.dutyCycle -= 3200;

           // sym_count-=10;

             }
            MAP_Timer_A_generatePWM(TIMER_A0_BASE, &pwmConfig);
}



}

//ISR FOR TEMPERATURE
void ADC14_IRQHandler(void)
{
    uint64_t status;
    int16_t conRes;

    status = ADC14_getEnabledInterruptStatus();
    ADC14_clearInterruptFlag(status);

    if(status & ADC_INT0)
    {
        conRes = ((ADC14_getResult(ADC_MEM0) - cal30) * 55);
        tempC = (conRes / calDifference) + 30.0f;
        tempF = tempC * 9.0f / 5.0f + 32.0f;
        tempK = tempC + 273;
    }
}

// Converts a floating point number to string.
void ftoa(float n, char *res, int afterpoint)
{
    // Extract integer part
    int ipart = (int)n;

    // Extract floating part
    float fpart = n - (float)ipart;

    // convert integer part to string
    int i = intToStr(ipart, res, 0);

    // check for display option after point
    if (afterpoint != 0)
    {
        res[i] = '.';  // add dot

        // Get the value of fraction part upto given no.
        // of points after dot. The third parameter is needed
        // to handle cases like 233.007
        fpart = fpart * pow(10, afterpoint);

        value_i_temp = intToStr((int)fpart, res + i + 1, afterpoint);
       //  int intToStr(int x, char str[], int d);
    }
}


int intToStr(int x, char str[], int d)
{
    int i = 0;
    while (x)
    {
        str[i++] = (x%10) + '0';
        x = x/10;
    }

    // If number of digits required is more, then
    // add 0s at the beginning
    while (i < d)
        str[i++] = '0';

    reverse(str, i);
    str[i] = '\0';
    return i;
}

// reverses a string 'str' of length 'len'
void reverse(char *str, int len)
{
    int i=0, j=len-1, temp;
    while (i<j)
    {
        temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++; j--;
    }
}
