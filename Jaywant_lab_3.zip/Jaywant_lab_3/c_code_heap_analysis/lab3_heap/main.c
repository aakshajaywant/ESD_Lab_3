#include <at89c51ed2.h>       //also includes 8052.h and 8051.h
#include <mc51/mcs51reg.h>
#include <mcs51/8051.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#ifndef HEAP_SIZE
#define HEAP_SIZE 4000
#endif

__xdata char __sdcc_heap[HEAP_SIZE];
const unsigned int __sdcc_heap_size = HEAP_SIZE;

/* -------------------------------------------------- */
//          GLOBALS
/* -------------------------------------------------- */
// Note: A global variable like this is accessible anywhere in this file
//       What does volatile mean to the compiler?
volatile int8_t gg = 0;


/* -------------------------------------------------- */
//          FUNCTION DEFINITIONS
/* -------------------------------------------------- */
// Note: Generally functions should be declared and defined in files outside of main
//       e.g. in strfuncs.c and strfuncs.h . Here they are included in a single file
//       to make compilation of this example easier

_sdcc_external_startup()
{
// Note: Here is where you would put code to enable your internal RAM
//////    //       This code runs early in uC initialization and should be kept
//////    //       as small as possible. See section 4.1.4 of SDCC 3.9.0 Manual
    return 0;
}
//// Note: In a function file, each function should have a small explanation of its args and returns

// putchar takes a char and TX's it. Blocking. No return value.
int putchar (int c)
{
    // Note: Compare the asm generated for the next three lines
    //       They all accomplish the same thing, but is the asm the same?
    while (!TI);
    //while (TI == 0);
    //while ((SCON & 0x02) == 0);
     TI = 0;
    SBUF = c;           // load serial port with transmit value
             // clear TI flag

    return 1;
}

int getchar (void)
{
    // Note: Compare the asm generated for the next three lines
    //       They all accomplish the same thing, but is the asm the same?
    while (!RI);
    //while ((SCON & 0x01) == 0);
    //while (RI == 0);

    RI = 0;                         // clear RI flag
    return SBUF;                    // return character from SBUF
}

int main()
{
 //   int *ptr;
//    int a;
//    a=getchar();
//    printf("Enter the buffer size");
//    putchar(a);
//    return 0;
//ptr = (int *)malloc(4*sizeof(int));

printf("Start memory address ");

//*ptr=5;
//if (ptr == NULL)
//{
//printf_tiny("Memory not allocated.\n");
//
//}
//else
//   {
//       // Memory has been successfully allocated
//       printf_tiny("\n\rMemory successfully allocated using malloc.\n\r");
//   }
//for(int i=0;i<16;i++)
//   {
//            printf("\n\rmemory address is: \t %p",ptr);
//            ++ptr;
//   }
//

   return 0;


}

