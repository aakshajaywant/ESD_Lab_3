                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 3.9.0 #11195 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module main
                                      6 	.optsdcc -mmcs51 --model-large
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl ___sdcc_heap_size
                                     12 	.globl _main
                                     13 	.globl _buffer_input
                                     14 	.globl __sdcc_external_startup
                                     15 	.globl _dataout
                                     16 	.globl _free
                                     17 	.globl _malloc
                                     18 	.globl _atoi
                                     19 	.globl _printf
                                     20 	.globl _CY
                                     21 	.globl _AC
                                     22 	.globl _F0
                                     23 	.globl _RS1
                                     24 	.globl _RS0
                                     25 	.globl _OV
                                     26 	.globl _F1
                                     27 	.globl _P
                                     28 	.globl _PS
                                     29 	.globl _PT1
                                     30 	.globl _PX1
                                     31 	.globl _PT0
                                     32 	.globl _PX0
                                     33 	.globl _RD
                                     34 	.globl _WR
                                     35 	.globl _T1
                                     36 	.globl _T0
                                     37 	.globl _INT1
                                     38 	.globl _INT0
                                     39 	.globl _TXD
                                     40 	.globl _RXD
                                     41 	.globl _P3_7
                                     42 	.globl _P3_6
                                     43 	.globl _P3_5
                                     44 	.globl _P3_4
                                     45 	.globl _P3_3
                                     46 	.globl _P3_2
                                     47 	.globl _P3_1
                                     48 	.globl _P3_0
                                     49 	.globl _EA
                                     50 	.globl _ES
                                     51 	.globl _ET1
                                     52 	.globl _EX1
                                     53 	.globl _ET0
                                     54 	.globl _EX0
                                     55 	.globl _P2_7
                                     56 	.globl _P2_6
                                     57 	.globl _P2_5
                                     58 	.globl _P2_4
                                     59 	.globl _P2_3
                                     60 	.globl _P2_2
                                     61 	.globl _P2_1
                                     62 	.globl _P2_0
                                     63 	.globl _SM0
                                     64 	.globl _SM1
                                     65 	.globl _SM2
                                     66 	.globl _REN
                                     67 	.globl _TB8
                                     68 	.globl _RB8
                                     69 	.globl _TI
                                     70 	.globl _RI
                                     71 	.globl _P1_7
                                     72 	.globl _P1_6
                                     73 	.globl _P1_5
                                     74 	.globl _P1_4
                                     75 	.globl _P1_3
                                     76 	.globl _P1_2
                                     77 	.globl _P1_1
                                     78 	.globl _P1_0
                                     79 	.globl _TF1
                                     80 	.globl _TR1
                                     81 	.globl _TF0
                                     82 	.globl _TR0
                                     83 	.globl _IE1
                                     84 	.globl _IT1
                                     85 	.globl _IE0
                                     86 	.globl _IT0
                                     87 	.globl _P0_7
                                     88 	.globl _P0_6
                                     89 	.globl _P0_5
                                     90 	.globl _P0_4
                                     91 	.globl _P0_3
                                     92 	.globl _P0_2
                                     93 	.globl _P0_1
                                     94 	.globl _P0_0
                                     95 	.globl _TXD0
                                     96 	.globl _RXD0
                                     97 	.globl _BREG_F7
                                     98 	.globl _BREG_F6
                                     99 	.globl _BREG_F5
                                    100 	.globl _BREG_F4
                                    101 	.globl _BREG_F3
                                    102 	.globl _BREG_F2
                                    103 	.globl _BREG_F1
                                    104 	.globl _BREG_F0
                                    105 	.globl _P5_7
                                    106 	.globl _P5_6
                                    107 	.globl _P5_5
                                    108 	.globl _P5_4
                                    109 	.globl _P5_3
                                    110 	.globl _P5_2
                                    111 	.globl _P5_1
                                    112 	.globl _P5_0
                                    113 	.globl _P4_7
                                    114 	.globl _P4_6
                                    115 	.globl _P4_5
                                    116 	.globl _P4_4
                                    117 	.globl _P4_3
                                    118 	.globl _P4_2
                                    119 	.globl _P4_1
                                    120 	.globl _P4_0
                                    121 	.globl _PX0L
                                    122 	.globl _PT0L
                                    123 	.globl _PX1L
                                    124 	.globl _PT1L
                                    125 	.globl _PSL
                                    126 	.globl _PT2L
                                    127 	.globl _PPCL
                                    128 	.globl _EC
                                    129 	.globl _CCF0
                                    130 	.globl _CCF1
                                    131 	.globl _CCF2
                                    132 	.globl _CCF3
                                    133 	.globl _CCF4
                                    134 	.globl _CR
                                    135 	.globl _CF
                                    136 	.globl _TF2
                                    137 	.globl _EXF2
                                    138 	.globl _RCLK
                                    139 	.globl _TCLK
                                    140 	.globl _EXEN2
                                    141 	.globl _TR2
                                    142 	.globl _C_T2
                                    143 	.globl _CP_RL2
                                    144 	.globl _T2CON_7
                                    145 	.globl _T2CON_6
                                    146 	.globl _T2CON_5
                                    147 	.globl _T2CON_4
                                    148 	.globl _T2CON_3
                                    149 	.globl _T2CON_2
                                    150 	.globl _T2CON_1
                                    151 	.globl _T2CON_0
                                    152 	.globl _PT2
                                    153 	.globl _ET2
                                    154 	.globl _B
                                    155 	.globl _ACC
                                    156 	.globl _PSW
                                    157 	.globl _IP
                                    158 	.globl _P3
                                    159 	.globl _IE
                                    160 	.globl _P2
                                    161 	.globl _SBUF
                                    162 	.globl _SCON
                                    163 	.globl _P1
                                    164 	.globl _TH1
                                    165 	.globl _TH0
                                    166 	.globl _TL1
                                    167 	.globl _TL0
                                    168 	.globl _TMOD
                                    169 	.globl _TCON
                                    170 	.globl _PCON
                                    171 	.globl _DPH
                                    172 	.globl _DPL
                                    173 	.globl _SP
                                    174 	.globl _P0
                                    175 	.globl _SBUF0
                                    176 	.globl _DP0L
                                    177 	.globl _DP0H
                                    178 	.globl _EECON
                                    179 	.globl _KBF
                                    180 	.globl _KBE
                                    181 	.globl _KBLS
                                    182 	.globl _BRL
                                    183 	.globl _BDRCON
                                    184 	.globl _T2MOD
                                    185 	.globl _SPDAT
                                    186 	.globl _SPSTA
                                    187 	.globl _SPCON
                                    188 	.globl _SADEN
                                    189 	.globl _SADDR
                                    190 	.globl _WDTPRG
                                    191 	.globl _WDTRST
                                    192 	.globl _P5
                                    193 	.globl _P4
                                    194 	.globl _IPH1
                                    195 	.globl _IPL1
                                    196 	.globl _IPH0
                                    197 	.globl _IPL0
                                    198 	.globl _IEN1
                                    199 	.globl _IEN0
                                    200 	.globl _CMOD
                                    201 	.globl _CL
                                    202 	.globl _CH
                                    203 	.globl _CCON
                                    204 	.globl _CCAPM4
                                    205 	.globl _CCAPM3
                                    206 	.globl _CCAPM2
                                    207 	.globl _CCAPM1
                                    208 	.globl _CCAPM0
                                    209 	.globl _CCAP4L
                                    210 	.globl _CCAP3L
                                    211 	.globl _CCAP2L
                                    212 	.globl _CCAP1L
                                    213 	.globl _CCAP0L
                                    214 	.globl _CCAP4H
                                    215 	.globl _CCAP3H
                                    216 	.globl _CCAP2H
                                    217 	.globl _CCAP1H
                                    218 	.globl _CCAP0H
                                    219 	.globl _CKCON1
                                    220 	.globl _CKCON0
                                    221 	.globl _CKRL
                                    222 	.globl _AUXR1
                                    223 	.globl _AUXR
                                    224 	.globl _TH2
                                    225 	.globl _TL2
                                    226 	.globl _RCAP2H
                                    227 	.globl _RCAP2L
                                    228 	.globl _T2CON
                                    229 	.globl _gg
                                    230 	.globl _count_forenter
                                    231 	.globl _out_of_loop
                                    232 	.globl _ip_user
                                    233 	.globl _temp0_ptr
                                    234 	.globl _input_size
                                    235 	.globl ___sdcc_heap
                                    236 	.globl _val
                                    237 	.globl _putchar
                                    238 	.globl _getchar
                                    239 ;--------------------------------------------------------
                                    240 ; special function registers
                                    241 ;--------------------------------------------------------
                                    242 	.area RSEG    (ABS,DATA)
      000000                        243 	.org 0x0000
                           0000C8   244 _T2CON	=	0x00c8
                           0000CA   245 _RCAP2L	=	0x00ca
                           0000CB   246 _RCAP2H	=	0x00cb
                           0000CC   247 _TL2	=	0x00cc
                           0000CD   248 _TH2	=	0x00cd
                           00008E   249 _AUXR	=	0x008e
                           0000A2   250 _AUXR1	=	0x00a2
                           000097   251 _CKRL	=	0x0097
                           00008F   252 _CKCON0	=	0x008f
                           0000AF   253 _CKCON1	=	0x00af
                           0000FA   254 _CCAP0H	=	0x00fa
                           0000FB   255 _CCAP1H	=	0x00fb
                           0000FC   256 _CCAP2H	=	0x00fc
                           0000FD   257 _CCAP3H	=	0x00fd
                           0000FE   258 _CCAP4H	=	0x00fe
                           0000EA   259 _CCAP0L	=	0x00ea
                           0000EB   260 _CCAP1L	=	0x00eb
                           0000EC   261 _CCAP2L	=	0x00ec
                           0000ED   262 _CCAP3L	=	0x00ed
                           0000EE   263 _CCAP4L	=	0x00ee
                           0000DA   264 _CCAPM0	=	0x00da
                           0000DB   265 _CCAPM1	=	0x00db
                           0000DC   266 _CCAPM2	=	0x00dc
                           0000DD   267 _CCAPM3	=	0x00dd
                           0000DE   268 _CCAPM4	=	0x00de
                           0000D8   269 _CCON	=	0x00d8
                           0000F9   270 _CH	=	0x00f9
                           0000E9   271 _CL	=	0x00e9
                           0000D9   272 _CMOD	=	0x00d9
                           0000A8   273 _IEN0	=	0x00a8
                           0000B1   274 _IEN1	=	0x00b1
                           0000B8   275 _IPL0	=	0x00b8
                           0000B7   276 _IPH0	=	0x00b7
                           0000B2   277 _IPL1	=	0x00b2
                           0000B3   278 _IPH1	=	0x00b3
                           0000C0   279 _P4	=	0x00c0
                           0000E8   280 _P5	=	0x00e8
                           0000A6   281 _WDTRST	=	0x00a6
                           0000A7   282 _WDTPRG	=	0x00a7
                           0000A9   283 _SADDR	=	0x00a9
                           0000B9   284 _SADEN	=	0x00b9
                           0000C3   285 _SPCON	=	0x00c3
                           0000C4   286 _SPSTA	=	0x00c4
                           0000C5   287 _SPDAT	=	0x00c5
                           0000C9   288 _T2MOD	=	0x00c9
                           00009B   289 _BDRCON	=	0x009b
                           00009A   290 _BRL	=	0x009a
                           00009C   291 _KBLS	=	0x009c
                           00009D   292 _KBE	=	0x009d
                           00009E   293 _KBF	=	0x009e
                           0000D2   294 _EECON	=	0x00d2
                           000083   295 _DP0H	=	0x0083
                           000082   296 _DP0L	=	0x0082
                           000099   297 _SBUF0	=	0x0099
                           000080   298 _P0	=	0x0080
                           000081   299 _SP	=	0x0081
                           000082   300 _DPL	=	0x0082
                           000083   301 _DPH	=	0x0083
                           000087   302 _PCON	=	0x0087
                           000088   303 _TCON	=	0x0088
                           000089   304 _TMOD	=	0x0089
                           00008A   305 _TL0	=	0x008a
                           00008B   306 _TL1	=	0x008b
                           00008C   307 _TH0	=	0x008c
                           00008D   308 _TH1	=	0x008d
                           000090   309 _P1	=	0x0090
                           000098   310 _SCON	=	0x0098
                           000099   311 _SBUF	=	0x0099
                           0000A0   312 _P2	=	0x00a0
                           0000A8   313 _IE	=	0x00a8
                           0000B0   314 _P3	=	0x00b0
                           0000B8   315 _IP	=	0x00b8
                           0000D0   316 _PSW	=	0x00d0
                           0000E0   317 _ACC	=	0x00e0
                           0000F0   318 _B	=	0x00f0
                                    319 ;--------------------------------------------------------
                                    320 ; special function bits
                                    321 ;--------------------------------------------------------
                                    322 	.area RSEG    (ABS,DATA)
      000000                        323 	.org 0x0000
                           0000AD   324 _ET2	=	0x00ad
                           0000BD   325 _PT2	=	0x00bd
                           0000C8   326 _T2CON_0	=	0x00c8
                           0000C9   327 _T2CON_1	=	0x00c9
                           0000CA   328 _T2CON_2	=	0x00ca
                           0000CB   329 _T2CON_3	=	0x00cb
                           0000CC   330 _T2CON_4	=	0x00cc
                           0000CD   331 _T2CON_5	=	0x00cd
                           0000CE   332 _T2CON_6	=	0x00ce
                           0000CF   333 _T2CON_7	=	0x00cf
                           0000C8   334 _CP_RL2	=	0x00c8
                           0000C9   335 _C_T2	=	0x00c9
                           0000CA   336 _TR2	=	0x00ca
                           0000CB   337 _EXEN2	=	0x00cb
                           0000CC   338 _TCLK	=	0x00cc
                           0000CD   339 _RCLK	=	0x00cd
                           0000CE   340 _EXF2	=	0x00ce
                           0000CF   341 _TF2	=	0x00cf
                           0000DF   342 _CF	=	0x00df
                           0000DE   343 _CR	=	0x00de
                           0000DC   344 _CCF4	=	0x00dc
                           0000DB   345 _CCF3	=	0x00db
                           0000DA   346 _CCF2	=	0x00da
                           0000D9   347 _CCF1	=	0x00d9
                           0000D8   348 _CCF0	=	0x00d8
                           0000AE   349 _EC	=	0x00ae
                           0000BE   350 _PPCL	=	0x00be
                           0000BD   351 _PT2L	=	0x00bd
                           0000BC   352 _PSL	=	0x00bc
                           0000BB   353 _PT1L	=	0x00bb
                           0000BA   354 _PX1L	=	0x00ba
                           0000B9   355 _PT0L	=	0x00b9
                           0000B8   356 _PX0L	=	0x00b8
                           0000C0   357 _P4_0	=	0x00c0
                           0000C1   358 _P4_1	=	0x00c1
                           0000C2   359 _P4_2	=	0x00c2
                           0000C3   360 _P4_3	=	0x00c3
                           0000C4   361 _P4_4	=	0x00c4
                           0000C5   362 _P4_5	=	0x00c5
                           0000C6   363 _P4_6	=	0x00c6
                           0000C7   364 _P4_7	=	0x00c7
                           0000E8   365 _P5_0	=	0x00e8
                           0000E9   366 _P5_1	=	0x00e9
                           0000EA   367 _P5_2	=	0x00ea
                           0000EB   368 _P5_3	=	0x00eb
                           0000EC   369 _P5_4	=	0x00ec
                           0000ED   370 _P5_5	=	0x00ed
                           0000EE   371 _P5_6	=	0x00ee
                           0000EF   372 _P5_7	=	0x00ef
                           0000F0   373 _BREG_F0	=	0x00f0
                           0000F1   374 _BREG_F1	=	0x00f1
                           0000F2   375 _BREG_F2	=	0x00f2
                           0000F3   376 _BREG_F3	=	0x00f3
                           0000F4   377 _BREG_F4	=	0x00f4
                           0000F5   378 _BREG_F5	=	0x00f5
                           0000F6   379 _BREG_F6	=	0x00f6
                           0000F7   380 _BREG_F7	=	0x00f7
                           0000B0   381 _RXD0	=	0x00b0
                           0000B1   382 _TXD0	=	0x00b1
                           000080   383 _P0_0	=	0x0080
                           000081   384 _P0_1	=	0x0081
                           000082   385 _P0_2	=	0x0082
                           000083   386 _P0_3	=	0x0083
                           000084   387 _P0_4	=	0x0084
                           000085   388 _P0_5	=	0x0085
                           000086   389 _P0_6	=	0x0086
                           000087   390 _P0_7	=	0x0087
                           000088   391 _IT0	=	0x0088
                           000089   392 _IE0	=	0x0089
                           00008A   393 _IT1	=	0x008a
                           00008B   394 _IE1	=	0x008b
                           00008C   395 _TR0	=	0x008c
                           00008D   396 _TF0	=	0x008d
                           00008E   397 _TR1	=	0x008e
                           00008F   398 _TF1	=	0x008f
                           000090   399 _P1_0	=	0x0090
                           000091   400 _P1_1	=	0x0091
                           000092   401 _P1_2	=	0x0092
                           000093   402 _P1_3	=	0x0093
                           000094   403 _P1_4	=	0x0094
                           000095   404 _P1_5	=	0x0095
                           000096   405 _P1_6	=	0x0096
                           000097   406 _P1_7	=	0x0097
                           000098   407 _RI	=	0x0098
                           000099   408 _TI	=	0x0099
                           00009A   409 _RB8	=	0x009a
                           00009B   410 _TB8	=	0x009b
                           00009C   411 _REN	=	0x009c
                           00009D   412 _SM2	=	0x009d
                           00009E   413 _SM1	=	0x009e
                           00009F   414 _SM0	=	0x009f
                           0000A0   415 _P2_0	=	0x00a0
                           0000A1   416 _P2_1	=	0x00a1
                           0000A2   417 _P2_2	=	0x00a2
                           0000A3   418 _P2_3	=	0x00a3
                           0000A4   419 _P2_4	=	0x00a4
                           0000A5   420 _P2_5	=	0x00a5
                           0000A6   421 _P2_6	=	0x00a6
                           0000A7   422 _P2_7	=	0x00a7
                           0000A8   423 _EX0	=	0x00a8
                           0000A9   424 _ET0	=	0x00a9
                           0000AA   425 _EX1	=	0x00aa
                           0000AB   426 _ET1	=	0x00ab
                           0000AC   427 _ES	=	0x00ac
                           0000AF   428 _EA	=	0x00af
                           0000B0   429 _P3_0	=	0x00b0
                           0000B1   430 _P3_1	=	0x00b1
                           0000B2   431 _P3_2	=	0x00b2
                           0000B3   432 _P3_3	=	0x00b3
                           0000B4   433 _P3_4	=	0x00b4
                           0000B5   434 _P3_5	=	0x00b5
                           0000B6   435 _P3_6	=	0x00b6
                           0000B7   436 _P3_7	=	0x00b7
                           0000B0   437 _RXD	=	0x00b0
                           0000B1   438 _TXD	=	0x00b1
                           0000B2   439 _INT0	=	0x00b2
                           0000B3   440 _INT1	=	0x00b3
                           0000B4   441 _T0	=	0x00b4
                           0000B5   442 _T1	=	0x00b5
                           0000B6   443 _WR	=	0x00b6
                           0000B7   444 _RD	=	0x00b7
                           0000B8   445 _PX0	=	0x00b8
                           0000B9   446 _PT0	=	0x00b9
                           0000BA   447 _PX1	=	0x00ba
                           0000BB   448 _PT1	=	0x00bb
                           0000BC   449 _PS	=	0x00bc
                           0000D0   450 _P	=	0x00d0
                           0000D1   451 _F1	=	0x00d1
                           0000D2   452 _OV	=	0x00d2
                           0000D3   453 _RS0	=	0x00d3
                           0000D4   454 _RS1	=	0x00d4
                           0000D5   455 _F0	=	0x00d5
                           0000D6   456 _AC	=	0x00d6
                           0000D7   457 _CY	=	0x00d7
                                    458 ;--------------------------------------------------------
                                    459 ; overlayable register banks
                                    460 ;--------------------------------------------------------
                                    461 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        462 	.ds 8
                                    463 ;--------------------------------------------------------
                                    464 ; internal ram data
                                    465 ;--------------------------------------------------------
                                    466 	.area DSEG    (DATA)
      000008                        467 _main_sloc0_1_0:
      000008                        468 	.ds 2
      00000A                        469 _main_sloc1_1_0:
      00000A                        470 	.ds 3
      00000D                        471 _main_sloc2_1_0:
      00000D                        472 	.ds 2
      00000F                        473 _main_sloc3_1_0:
      00000F                        474 	.ds 3
      000012                        475 _main_sloc4_1_0:
      000012                        476 	.ds 2
      000014                        477 _main_sloc5_1_0:
      000014                        478 	.ds 3
      000017                        479 _main_sloc6_1_0:
      000017                        480 	.ds 1
      000018                        481 _main_sloc7_1_0:
      000018                        482 	.ds 1
      000019                        483 _main_sloc8_1_0:
      000019                        484 	.ds 1
      00001A                        485 _main_sloc9_1_0:
      00001A                        486 	.ds 2
      00001C                        487 _main_sloc10_1_0:
      00001C                        488 	.ds 2
      00001E                        489 _main_sloc11_1_0:
      00001E                        490 	.ds 2
      000020                        491 _main_sloc12_1_0:
      000020                        492 	.ds 2
      000022                        493 _main_sloc13_1_0:
      000022                        494 	.ds 2
      000024                        495 _main_sloc14_1_0:
      000024                        496 	.ds 3
      000027                        497 _main_sloc15_1_0:
      000027                        498 	.ds 3
                                    499 ;--------------------------------------------------------
                                    500 ; overlayable items in internal ram 
                                    501 ;--------------------------------------------------------
                                    502 ;--------------------------------------------------------
                                    503 ; Stack segment in internal ram 
                                    504 ;--------------------------------------------------------
                                    505 	.area	SSEG
      000038                        506 __start__stack:
      000038                        507 	.ds	1
                                    508 
                                    509 ;--------------------------------------------------------
                                    510 ; indirectly addressable internal ram data
                                    511 ;--------------------------------------------------------
                                    512 	.area ISEG    (DATA)
                                    513 ;--------------------------------------------------------
                                    514 ; absolute internal ram data
                                    515 ;--------------------------------------------------------
                                    516 	.area IABS    (ABS,DATA)
                                    517 	.area IABS    (ABS,DATA)
                                    518 ;--------------------------------------------------------
                                    519 ; bit data
                                    520 ;--------------------------------------------------------
                                    521 	.area BSEG    (BIT)
                                    522 ;--------------------------------------------------------
                                    523 ; paged external ram data
                                    524 ;--------------------------------------------------------
                                    525 	.area PSEG    (PAG,XDATA)
                                    526 ;--------------------------------------------------------
                                    527 ; external ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area XSEG    (XDATA)
                           00FF01   530 _val	=	0xff01
      000400                        531 _dataout_x_65536_63:
      000400                        532 	.ds 1
      000401                        533 ___sdcc_heap::
      000401                        534 	.ds 4000
      0013A1                        535 _putchar_c_65536_66:
      0013A1                        536 	.ds 2
      0013A3                        537 _input_size::
      0013A3                        538 	.ds 2
      0013A5                        539 _temp0_ptr::
      0013A5                        540 	.ds 3
      0013A8                        541 _ip_user::
      0013A8                        542 	.ds 1
      0013A9                        543 _out_of_loop::
      0013A9                        544 	.ds 1
      0013AA                        545 _count_forenter::
      0013AA                        546 	.ds 2
      0013AC                        547 _buffer_input_b_65536_70:
      0013AC                        548 	.ds 10
      0013B6                        549 _main_buffer_size_131072_75:
      0013B6                        550 	.ds 2
      0013B8                        551 _main_buffer0_size_131072_75:
      0013B8                        552 	.ds 2
      0013BA                        553 _main_buff0_ptr_131072_75:
      0013BA                        554 	.ds 3
      0013BD                        555 _main_buff0_base_131072_75:
      0013BD                        556 	.ds 3
      0013C0                        557 _main_save_start_to_buff0_131072_75:
      0013C0                        558 	.ds 3
      0013C3                        559 _main_buffer_4comp_131072_75:
      0013C3                        560 	.ds 2
      0013C5                        561 _main_arr_forfree_space_131072_75:
      0013C5                        562 	.ds 60
      001401                        563 _main_arr_to_store_131072_75:
      001401                        564 	.ds 30
      00141F                        565 _main_buffptr_forplus_131072_75:
      00141F                        566 	.ds 90
      001479                        567 _main_valid_num_131072_75:
      001479                        568 	.ds 1
                                    569 ;--------------------------------------------------------
                                    570 ; absolute external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XABS    (ABS,XDATA)
                                    573 ;--------------------------------------------------------
                                    574 ; external initialized ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area XISEG   (XDATA)
      0014CB                        577 _gg::
      0014CB                        578 	.ds 1
                                    579 	.area HOME    (CODE)
                                    580 	.area GSINIT0 (CODE)
                                    581 	.area GSINIT1 (CODE)
                                    582 	.area GSINIT2 (CODE)
                                    583 	.area GSINIT3 (CODE)
                                    584 	.area GSINIT4 (CODE)
                                    585 	.area GSINIT5 (CODE)
                                    586 	.area GSINIT  (CODE)
                                    587 	.area GSFINAL (CODE)
                                    588 	.area CSEG    (CODE)
                                    589 ;--------------------------------------------------------
                                    590 ; interrupt vector 
                                    591 ;--------------------------------------------------------
                                    592 	.area HOME    (CODE)
      003000                        593 __interrupt_vect:
      003000 02 30 06         [24]  594 	ljmp	__sdcc_gsinit_startup
                                    595 ;--------------------------------------------------------
                                    596 ; global & static initialisations
                                    597 ;--------------------------------------------------------
                                    598 	.area HOME    (CODE)
                                    599 	.area GSINIT  (CODE)
                                    600 	.area GSFINAL (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 	.globl __sdcc_gsinit_startup
                                    603 	.globl __sdcc_program_startup
                                    604 	.globl __start__stack
                                    605 	.globl __mcs51_genXINIT
                                    606 	.globl __mcs51_genXRAMCLEAR
                                    607 	.globl __mcs51_genRAMCLEAR
                                    608 	.area GSFINAL (CODE)
      00305F 02 30 03         [24]  609 	ljmp	__sdcc_program_startup
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
      003003                        615 __sdcc_program_startup:
      003003 02 31 1A         [24]  616 	ljmp	_main
                                    617 ;	return from main will return to caller
                                    618 ;--------------------------------------------------------
                                    619 ; code
                                    620 ;--------------------------------------------------------
                                    621 	.area CSEG    (CODE)
                                    622 ;------------------------------------------------------------
                                    623 ;Allocation info for local variables in function 'dataout'
                                    624 ;------------------------------------------------------------
                                    625 ;x                         Allocated with name '_dataout_x_65536_63'
                                    626 ;------------------------------------------------------------
                                    627 ;	D:\Codeblocks\lab3_v2\main.c:30: int dataout(uint8_t x)
                                    628 ;	-----------------------------------------
                                    629 ;	 function dataout
                                    630 ;	-----------------------------------------
      003062                        631 _dataout:
                           000007   632 	ar7 = 0x07
                           000006   633 	ar6 = 0x06
                           000005   634 	ar5 = 0x05
                           000004   635 	ar4 = 0x04
                           000003   636 	ar3 = 0x03
                           000002   637 	ar2 = 0x02
                           000001   638 	ar1 = 0x01
                           000000   639 	ar0 = 0x00
      003062 E5 82            [12]  640 	mov	a,dpl
      003064 90 04 00         [24]  641 	mov	dptr,#_dataout_x_65536_63
      003067 F0               [24]  642 	movx	@dptr,a
                                    643 ;	D:\Codeblocks\lab3_v2\main.c:34: val = x;
      003068 E0               [24]  644 	movx	a,@dptr
      003069 90 FF 01         [24]  645 	mov	dptr,#_val
      00306C F0               [24]  646 	movx	@dptr,a
                                    647 ;	D:\Codeblocks\lab3_v2\main.c:36: }
      00306D 22               [24]  648 	ret
                                    649 ;------------------------------------------------------------
                                    650 ;Allocation info for local variables in function '_sdcc_external_startup'
                                    651 ;------------------------------------------------------------
                                    652 ;	D:\Codeblocks\lab3_v2\main.c:56: _sdcc_external_startup()
                                    653 ;	-----------------------------------------
                                    654 ;	 function _sdcc_external_startup
                                    655 ;	-----------------------------------------
      00306E                        656 __sdcc_external_startup:
                                    657 ;	D:\Codeblocks\lab3_v2\main.c:61: return 0;
      00306E 90 00 00         [24]  658 	mov	dptr,#0x0000
                                    659 ;	D:\Codeblocks\lab3_v2\main.c:62: }
      003071 22               [24]  660 	ret
                                    661 ;------------------------------------------------------------
                                    662 ;Allocation info for local variables in function 'putchar'
                                    663 ;------------------------------------------------------------
                                    664 ;c                         Allocated with name '_putchar_c_65536_66'
                                    665 ;------------------------------------------------------------
                                    666 ;	D:\Codeblocks\lab3_v2\main.c:66: int putchar (int c)
                                    667 ;	-----------------------------------------
                                    668 ;	 function putchar
                                    669 ;	-----------------------------------------
      003072                        670 _putchar:
      003072 AF 83            [24]  671 	mov	r7,dph
      003074 E5 82            [12]  672 	mov	a,dpl
      003076 90 13 A1         [24]  673 	mov	dptr,#_putchar_c_65536_66
      003079 F0               [24]  674 	movx	@dptr,a
      00307A EF               [12]  675 	mov	a,r7
      00307B A3               [24]  676 	inc	dptr
      00307C F0               [24]  677 	movx	@dptr,a
                                    678 ;	D:\Codeblocks\lab3_v2\main.c:70: while (!TI);
      00307D                        679 00101$:
                                    680 ;	D:\Codeblocks\lab3_v2\main.c:73: TI = 0;
                                    681 ;	assignBit
      00307D 10 99 02         [24]  682 	jbc	_TI,00114$
      003080 80 FB            [24]  683 	sjmp	00101$
      003082                        684 00114$:
                                    685 ;	D:\Codeblocks\lab3_v2\main.c:74: SBUF = c;           // load serial port with transmit value
      003082 90 13 A1         [24]  686 	mov	dptr,#_putchar_c_65536_66
      003085 E0               [24]  687 	movx	a,@dptr
      003086 FE               [12]  688 	mov	r6,a
      003087 A3               [24]  689 	inc	dptr
      003088 E0               [24]  690 	movx	a,@dptr
      003089 8E 99            [24]  691 	mov	_SBUF,r6
                                    692 ;	D:\Codeblocks\lab3_v2\main.c:77: return 1;
      00308B 90 00 01         [24]  693 	mov	dptr,#0x0001
                                    694 ;	D:\Codeblocks\lab3_v2\main.c:78: }
      00308E 22               [24]  695 	ret
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'getchar'
                                    698 ;------------------------------------------------------------
                                    699 ;	D:\Codeblocks\lab3_v2\main.c:80: int getchar (void)
                                    700 ;	-----------------------------------------
                                    701 ;	 function getchar
                                    702 ;	-----------------------------------------
      00308F                        703 _getchar:
                                    704 ;	D:\Codeblocks\lab3_v2\main.c:84: while (!RI);
      00308F                        705 00101$:
                                    706 ;	D:\Codeblocks\lab3_v2\main.c:88: RI = 0;                         // clear RI flag
                                    707 ;	assignBit
      00308F 10 98 02         [24]  708 	jbc	_RI,00114$
      003092 80 FB            [24]  709 	sjmp	00101$
      003094                        710 00114$:
                                    711 ;	D:\Codeblocks\lab3_v2\main.c:89: return SBUF;                    // return character from SBUF
      003094 AE 99            [24]  712 	mov	r6,_SBUF
      003096 7F 00            [12]  713 	mov	r7,#0x00
      003098 8E 82            [24]  714 	mov	dpl,r6
      00309A 8F 83            [24]  715 	mov	dph,r7
                                    716 ;	D:\Codeblocks\lab3_v2\main.c:90: }
      00309C 22               [24]  717 	ret
                                    718 ;------------------------------------------------------------
                                    719 ;Allocation info for local variables in function 'buffer_input'
                                    720 ;------------------------------------------------------------
                                    721 ;b                         Allocated with name '_buffer_input_b_65536_70'
                                    722 ;a                         Allocated with name '_buffer_input_a_65536_70'
                                    723 ;i                         Allocated with name '_buffer_input_i_131072_71'
                                    724 ;------------------------------------------------------------
                                    725 ;	D:\Codeblocks\lab3_v2\main.c:100: int buffer_input()
                                    726 ;	-----------------------------------------
                                    727 ;	 function buffer_input
                                    728 ;	-----------------------------------------
      00309D                        729 _buffer_input:
                                    730 ;	D:\Codeblocks\lab3_v2\main.c:104: a=b;
                                    731 ;	D:\Codeblocks\lab3_v2\main.c:105: for(uint8_t i=0;i<4;i++)
      00309D 7F 00            [12]  732 	mov	r7,#0x00
      00309F                        733 00105$:
      00309F BF 04 00         [24]  734 	cjne	r7,#0x04,00121$
      0030A2                        735 00121$:
      0030A2 50 5C            [24]  736 	jnc	00103$
                                    737 ;	D:\Codeblocks\lab3_v2\main.c:107: *(a+i) = getchar();             //
      0030A4 EF               [12]  738 	mov	a,r7
      0030A5 24 AC            [12]  739 	add	a,#_buffer_input_b_65536_70
      0030A7 FC               [12]  740 	mov	r4,a
      0030A8 E4               [12]  741 	clr	a
      0030A9 34 13            [12]  742 	addc	a,#(_buffer_input_b_65536_70 >> 8)
      0030AB FD               [12]  743 	mov	r5,a
      0030AC 7E 00            [12]  744 	mov	r6,#0x00
      0030AE C0 07            [24]  745 	push	ar7
      0030B0 C0 06            [24]  746 	push	ar6
      0030B2 C0 05            [24]  747 	push	ar5
      0030B4 C0 04            [24]  748 	push	ar4
      0030B6 12 30 8F         [24]  749 	lcall	_getchar
      0030B9 AA 82            [24]  750 	mov	r2,dpl
      0030BB D0 04            [24]  751 	pop	ar4
      0030BD D0 05            [24]  752 	pop	ar5
      0030BF D0 06            [24]  753 	pop	ar6
      0030C1 8C 82            [24]  754 	mov	dpl,r4
      0030C3 8D 83            [24]  755 	mov	dph,r5
      0030C5 8E F0            [24]  756 	mov	b,r6
      0030C7 EA               [12]  757 	mov	a,r2
      0030C8 12 3E 1E         [24]  758 	lcall	__gptrput
                                    759 ;	D:\Codeblocks\lab3_v2\main.c:108: putchar(*(a+i));
      0030CB 7B 00            [12]  760 	mov	r3,#0x00
      0030CD 8A 82            [24]  761 	mov	dpl,r2
      0030CF 8B 83            [24]  762 	mov	dph,r3
      0030D1 C0 06            [24]  763 	push	ar6
      0030D3 C0 05            [24]  764 	push	ar5
      0030D5 C0 04            [24]  765 	push	ar4
      0030D7 12 30 72         [24]  766 	lcall	_putchar
      0030DA D0 04            [24]  767 	pop	ar4
      0030DC D0 05            [24]  768 	pop	ar5
      0030DE D0 06            [24]  769 	pop	ar6
      0030E0 D0 07            [24]  770 	pop	ar7
                                    771 ;	D:\Codeblocks\lab3_v2\main.c:110: if(*(a+i)== 0x0D)
      0030E2 8C 82            [24]  772 	mov	dpl,r4
      0030E4 8D 83            [24]  773 	mov	dph,r5
      0030E6 8E F0            [24]  774 	mov	b,r6
      0030E8 12 4A 6E         [24]  775 	lcall	__gptrget
      0030EB FC               [12]  776 	mov	r4,a
      0030EC BC 0D 0E         [24]  777 	cjne	r4,#0x0d,00106$
                                    778 ;	D:\Codeblocks\lab3_v2\main.c:112: count_forenter++;
      0030EF 90 13 AA         [24]  779 	mov	dptr,#_count_forenter
      0030F2 E0               [24]  780 	movx	a,@dptr
      0030F3 24 01            [12]  781 	add	a,#0x01
      0030F5 F0               [24]  782 	movx	@dptr,a
      0030F6 A3               [24]  783 	inc	dptr
      0030F7 E0               [24]  784 	movx	a,@dptr
      0030F8 34 00            [12]  785 	addc	a,#0x00
      0030FA F0               [24]  786 	movx	@dptr,a
                                    787 ;	D:\Codeblocks\lab3_v2\main.c:113: break;
      0030FB 80 03            [24]  788 	sjmp	00103$
      0030FD                        789 00106$:
                                    790 ;	D:\Codeblocks\lab3_v2\main.c:105: for(uint8_t i=0;i<4;i++)
      0030FD 0F               [12]  791 	inc	r7
      0030FE 80 9F            [24]  792 	sjmp	00105$
      003100                        793 00103$:
                                    794 ;	D:\Codeblocks\lab3_v2\main.c:116: input_size = atoi(a);
      003100 90 13 AC         [24]  795 	mov	dptr,#_buffer_input_b_65536_70
      003103 75 F0 00         [24]  796 	mov	b,#0x00
      003106 12 3C FE         [24]  797 	lcall	_atoi
      003109 AE 82            [24]  798 	mov	r6,dpl
      00310B AF 83            [24]  799 	mov	r7,dph
      00310D 90 13 A3         [24]  800 	mov	dptr,#_input_size
      003110 EE               [12]  801 	mov	a,r6
      003111 F0               [24]  802 	movx	@dptr,a
      003112 EF               [12]  803 	mov	a,r7
      003113 A3               [24]  804 	inc	dptr
      003114 F0               [24]  805 	movx	@dptr,a
                                    806 ;	D:\Codeblocks\lab3_v2\main.c:117: return input_size;
      003115 8E 82            [24]  807 	mov	dpl,r6
      003117 8F 83            [24]  808 	mov	dph,r7
                                    809 ;	D:\Codeblocks\lab3_v2\main.c:118: }
      003119 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'main'
                                    813 ;------------------------------------------------------------
                                    814 ;sloc0                     Allocated with name '_main_sloc0_1_0'
                                    815 ;sloc1                     Allocated with name '_main_sloc1_1_0'
                                    816 ;sloc2                     Allocated with name '_main_sloc2_1_0'
                                    817 ;sloc3                     Allocated with name '_main_sloc3_1_0'
                                    818 ;sloc4                     Allocated with name '_main_sloc4_1_0'
                                    819 ;sloc5                     Allocated with name '_main_sloc5_1_0'
                                    820 ;sloc6                     Allocated with name '_main_sloc6_1_0'
                                    821 ;sloc7                     Allocated with name '_main_sloc7_1_0'
                                    822 ;sloc8                     Allocated with name '_main_sloc8_1_0'
                                    823 ;sloc9                     Allocated with name '_main_sloc9_1_0'
                                    824 ;sloc10                    Allocated with name '_main_sloc10_1_0'
                                    825 ;sloc11                    Allocated with name '_main_sloc11_1_0'
                                    826 ;sloc12                    Allocated with name '_main_sloc12_1_0'
                                    827 ;sloc13                    Allocated with name '_main_sloc13_1_0'
                                    828 ;sloc14                    Allocated with name '_main_sloc14_1_0'
                                    829 ;sloc15                    Allocated with name '_main_sloc15_1_0'
                                    830 ;buffer_size               Allocated with name '_main_buffer_size_131072_75'
                                    831 ;buffer0_size              Allocated with name '_main_buffer0_size_131072_75'
                                    832 ;buff0_ptr                 Allocated with name '_main_buff0_ptr_131072_75'
                                    833 ;buff1_ptr                 Allocated with name '_main_buff1_ptr_131072_75'
                                    834 ;buff0_base                Allocated with name '_main_buff0_base_131072_75'
                                    835 ;save_start_to_buff0       Allocated with name '_main_save_start_to_buff0_131072_75'
                                    836 ;buffer_4comp              Allocated with name '_main_buffer_4comp_131072_75'
                                    837 ;arr_forfree_space         Allocated with name '_main_arr_forfree_space_131072_75'
                                    838 ;arr_to_store              Allocated with name '_main_arr_to_store_131072_75'
                                    839 ;buffptr_forplus           Allocated with name '_main_buffptr_forplus_131072_75'
                                    840 ;count                     Allocated with name '_main_count_131072_75'
                                    841 ;user_alpha                Allocated with name '_main_user_alpha_131072_75'
                                    842 ;valid_num                 Allocated with name '_main_valid_num_131072_75'
                                    843 ;buffer_op1                Allocated with name '_main_buffer_op1_131073_79'
                                    844 ;i                         Allocated with name '_main_i_393217_92'
                                    845 ;i                         Allocated with name '_main_i_393217_94'
                                    846 ;i                         Allocated with name '_main_i_327681_98'
                                    847 ;i                         Allocated with name '_main_i_327681_102'
                                    848 ;------------------------------------------------------------
                                    849 ;	D:\Codeblocks\lab3_v2\main.c:122: int main()
                                    850 ;	-----------------------------------------
                                    851 ;	 function main
                                    852 ;	-----------------------------------------
      00311A                        853 _main:
                                    854 ;	D:\Codeblocks\lab3_v2\main.c:124: while(1)
      00311A                        855 00156$:
                                    856 ;	D:\Codeblocks\lab3_v2\main.c:128: uint16_t buffer_4comp=0;
      00311A 90 13 C3         [24]  857 	mov	dptr,#_main_buffer_4comp_131072_75
      00311D E4               [12]  858 	clr	a
      00311E F0               [24]  859 	movx	@dptr,a
      00311F A3               [24]  860 	inc	dptr
      003120 F0               [24]  861 	movx	@dptr,a
                                    862 ;	D:\Codeblocks\lab3_v2\main.c:144: do
      003121                        863 00103$:
                                    864 ;	D:\Codeblocks\lab3_v2\main.c:146: printf("Enter BUFFER size\n");
      003121 74 8C            [12]  865 	mov	a,#___str_0
      003123 C0 E0            [24]  866 	push	acc
      003125 74 4A            [12]  867 	mov	a,#(___str_0 >> 8)
      003127 C0 E0            [24]  868 	push	acc
      003129 74 80            [12]  869 	mov	a,#0x80
      00312B C0 E0            [24]  870 	push	acc
      00312D 12 40 4C         [24]  871 	lcall	_printf
      003130 15 81            [12]  872 	dec	sp
      003132 15 81            [12]  873 	dec	sp
      003134 15 81            [12]  874 	dec	sp
                                    875 ;	D:\Codeblocks\lab3_v2\main.c:148: buffer_input();
      003136 12 30 9D         [24]  876 	lcall	_buffer_input
                                    877 ;	D:\Codeblocks\lab3_v2\main.c:149: buffer_size = input_size;
      003139 90 13 A3         [24]  878 	mov	dptr,#_input_size
      00313C E0               [24]  879 	movx	a,@dptr
      00313D FE               [12]  880 	mov	r6,a
      00313E A3               [24]  881 	inc	dptr
      00313F E0               [24]  882 	movx	a,@dptr
      003140 FF               [12]  883 	mov	r7,a
      003141 90 13 B6         [24]  884 	mov	dptr,#_main_buffer_size_131072_75
      003144 EE               [12]  885 	mov	a,r6
      003145 F0               [24]  886 	movx	@dptr,a
      003146 EF               [12]  887 	mov	a,r7
      003147 A3               [24]  888 	inc	dptr
      003148 F0               [24]  889 	movx	@dptr,a
                                    890 ;	D:\Codeblocks\lab3_v2\main.c:150: buffer0_size= buffer_size; //saving the input buffer size into buffer0_size
      003149 90 13 B8         [24]  891 	mov	dptr,#_main_buffer0_size_131072_75
      00314C EE               [12]  892 	mov	a,r6
      00314D F0               [24]  893 	movx	@dptr,a
      00314E EF               [12]  894 	mov	a,r7
      00314F A3               [24]  895 	inc	dptr
      003150 F0               [24]  896 	movx	@dptr,a
                                    897 ;	D:\Codeblocks\lab3_v2\main.c:152: printf("The BUFFER0 size entered by the user is %d\n",buffer_size);
      003151 C0 06            [24]  898 	push	ar6
      003153 C0 07            [24]  899 	push	ar7
      003155 74 9F            [12]  900 	mov	a,#___str_1
      003157 C0 E0            [24]  901 	push	acc
      003159 74 4A            [12]  902 	mov	a,#(___str_1 >> 8)
      00315B C0 E0            [24]  903 	push	acc
      00315D 74 80            [12]  904 	mov	a,#0x80
      00315F C0 E0            [24]  905 	push	acc
      003161 12 40 4C         [24]  906 	lcall	_printf
      003164 E5 81            [12]  907 	mov	a,sp
      003166 24 FB            [12]  908 	add	a,#0xfb
      003168 F5 81            [12]  909 	mov	sp,a
                                    910 ;	D:\Codeblocks\lab3_v2\main.c:153: } while((buffer_size%(32))!=0 || buffer_size<32 || buffer_size>3200);
      00316A 90 13 B6         [24]  911 	mov	dptr,#_main_buffer_size_131072_75
      00316D E0               [24]  912 	movx	a,@dptr
      00316E FE               [12]  913 	mov	r6,a
      00316F A3               [24]  914 	inc	dptr
      003170 E0               [24]  915 	movx	a,@dptr
      003171 FF               [12]  916 	mov	r7,a
      003172 EE               [12]  917 	mov	a,r6
      003173 54 1F            [12]  918 	anl	a,#0x1f
      003175 70 AA            [24]  919 	jnz	00103$
      003177 C3               [12]  920 	clr	c
      003178 EE               [12]  921 	mov	a,r6
      003179 94 20            [12]  922 	subb	a,#0x20
      00317B EF               [12]  923 	mov	a,r7
      00317C 94 00            [12]  924 	subb	a,#0x00
      00317E 40 A1            [24]  925 	jc	00103$
      003180 74 80            [12]  926 	mov	a,#0x80
      003182 9E               [12]  927 	subb	a,r6
      003183 74 0C            [12]  928 	mov	a,#0x0c
      003185 9F               [12]  929 	subb	a,r7
      003186 40 99            [24]  930 	jc	00103$
                                    931 ;	D:\Codeblocks\lab3_v2\main.c:157: buff0_ptr = (int *)malloc(buffer_size*sizeof(uint8_t));
      003188 8E 82            [24]  932 	mov	dpl,r6
      00318A 8F 83            [24]  933 	mov	dph,r7
      00318C C0 07            [24]  934 	push	ar7
      00318E C0 06            [24]  935 	push	ar6
      003190 12 3E 95         [24]  936 	lcall	_malloc
      003193 AC 82            [24]  937 	mov	r4,dpl
      003195 AD 83            [24]  938 	mov	r5,dph
      003197 D0 06            [24]  939 	pop	ar6
      003199 D0 07            [24]  940 	pop	ar7
      00319B 8D 03            [24]  941 	mov	ar3,r5
      00319D 7D 00            [12]  942 	mov	r5,#0x00
      00319F 90 13 BA         [24]  943 	mov	dptr,#_main_buff0_ptr_131072_75
      0031A2 EC               [12]  944 	mov	a,r4
      0031A3 F0               [24]  945 	movx	@dptr,a
      0031A4 EB               [12]  946 	mov	a,r3
      0031A5 A3               [24]  947 	inc	dptr
      0031A6 F0               [24]  948 	movx	@dptr,a
      0031A7 ED               [12]  949 	mov	a,r5
      0031A8 A3               [24]  950 	inc	dptr
      0031A9 F0               [24]  951 	movx	@dptr,a
                                    952 ;	D:\Codeblocks\lab3_v2\main.c:159: if(buffer_size>1984)
      0031AA C3               [12]  953 	clr	c
      0031AB 74 C0            [12]  954 	mov	a,#0xc0
      0031AD 9E               [12]  955 	subb	a,r6
      0031AE 74 07            [12]  956 	mov	a,#0x07
      0031B0 9F               [12]  957 	subb	a,r7
      0031B1 40 03            [24]  958 	jc	00312$
      0031B3 02 32 4A         [24]  959 	ljmp	00111$
      0031B6                        960 00312$:
                                    961 ;	D:\Codeblocks\lab3_v2\main.c:161: do
      0031B6 8C 07            [24]  962 	mov	ar7,r4
      0031B8 8B 06            [24]  963 	mov	ar6,r3
      0031BA                        964 00107$:
                                    965 ;	D:\Codeblocks\lab3_v2\main.c:163: printf("Malloc Failed");
      0031BA C0 07            [24]  966 	push	ar7
      0031BC C0 06            [24]  967 	push	ar6
      0031BE C0 05            [24]  968 	push	ar5
      0031C0 74 CB            [12]  969 	mov	a,#___str_2
      0031C2 C0 E0            [24]  970 	push	acc
      0031C4 74 4A            [12]  971 	mov	a,#(___str_2 >> 8)
      0031C6 C0 E0            [24]  972 	push	acc
      0031C8 74 80            [12]  973 	mov	a,#0x80
      0031CA C0 E0            [24]  974 	push	acc
      0031CC 12 40 4C         [24]  975 	lcall	_printf
      0031CF 15 81            [12]  976 	dec	sp
      0031D1 15 81            [12]  977 	dec	sp
      0031D3 15 81            [12]  978 	dec	sp
      0031D5 D0 05            [24]  979 	pop	ar5
      0031D7 D0 06            [24]  980 	pop	ar6
      0031D9 D0 07            [24]  981 	pop	ar7
                                    982 ;	D:\Codeblocks\lab3_v2\main.c:164: free(buff0_ptr);
      0031DB 8F 02            [24]  983 	mov	ar2,r7
      0031DD 8E 03            [24]  984 	mov	ar3,r6
      0031DF 8D 04            [24]  985 	mov	ar4,r5
      0031E1 8A 82            [24]  986 	mov	dpl,r2
      0031E3 8B 83            [24]  987 	mov	dph,r3
      0031E5 8C F0            [24]  988 	mov	b,r4
      0031E7 C0 07            [24]  989 	push	ar7
      0031E9 C0 06            [24]  990 	push	ar6
      0031EB C0 05            [24]  991 	push	ar5
      0031ED 12 3B A7         [24]  992 	lcall	_free
                                    993 ;	D:\Codeblocks\lab3_v2\main.c:165: printf("Enter value smaller than 1985bytes");
      0031F0 74 D9            [12]  994 	mov	a,#___str_3
      0031F2 C0 E0            [24]  995 	push	acc
      0031F4 74 4A            [12]  996 	mov	a,#(___str_3 >> 8)
      0031F6 C0 E0            [24]  997 	push	acc
      0031F8 74 80            [12]  998 	mov	a,#0x80
      0031FA C0 E0            [24]  999 	push	acc
      0031FC 12 40 4C         [24] 1000 	lcall	_printf
      0031FF 15 81            [12] 1001 	dec	sp
      003201 15 81            [12] 1002 	dec	sp
      003203 15 81            [12] 1003 	dec	sp
                                   1004 ;	D:\Codeblocks\lab3_v2\main.c:166: buffer_input();
      003205 12 30 9D         [24] 1005 	lcall	_buffer_input
      003208 D0 05            [24] 1006 	pop	ar5
      00320A D0 06            [24] 1007 	pop	ar6
      00320C D0 07            [24] 1008 	pop	ar7
                                   1009 ;	D:\Codeblocks\lab3_v2\main.c:167: buffer_size = input_size;
      00320E 90 13 A3         [24] 1010 	mov	dptr,#_input_size
      003211 E0               [24] 1011 	movx	a,@dptr
      003212 FB               [12] 1012 	mov	r3,a
      003213 A3               [24] 1013 	inc	dptr
      003214 E0               [24] 1014 	movx	a,@dptr
      003215 FC               [12] 1015 	mov	r4,a
      003216 90 13 B6         [24] 1016 	mov	dptr,#_main_buffer_size_131072_75
      003219 EB               [12] 1017 	mov	a,r3
      00321A F0               [24] 1018 	movx	@dptr,a
      00321B EC               [12] 1019 	mov	a,r4
      00321C A3               [24] 1020 	inc	dptr
      00321D F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	D:\Codeblocks\lab3_v2\main.c:168: buffer0_size= buffer_size; //saving buffer size in buffer0_size incase it enters this loop
      00321E 90 13 B8         [24] 1023 	mov	dptr,#_main_buffer0_size_131072_75
      003221 EB               [12] 1024 	mov	a,r3
      003222 F0               [24] 1025 	movx	@dptr,a
      003223 EC               [12] 1026 	mov	a,r4
      003224 A3               [24] 1027 	inc	dptr
      003225 F0               [24] 1028 	movx	@dptr,a
                                   1029 ;	D:\Codeblocks\lab3_v2\main.c:169: }while((buffer_size%(32))!=0 || buffer_size>1984);
      003226 EB               [12] 1030 	mov	a,r3
      003227 54 1F            [12] 1031 	anl	a,#0x1f
      003229 70 8F            [24] 1032 	jnz	00107$
      00322B C3               [12] 1033 	clr	c
      00322C 74 C0            [12] 1034 	mov	a,#0xc0
      00322E 9B               [12] 1035 	subb	a,r3
      00322F 74 07            [12] 1036 	mov	a,#0x07
      003231 9C               [12] 1037 	subb	a,r4
      003232 40 86            [24] 1038 	jc	00107$
                                   1039 ;	D:\Codeblocks\lab3_v2\main.c:170: buff0_ptr = (int *)malloc(buffer_size*sizeof(uint8_t));
      003234 8B 82            [24] 1040 	mov	dpl,r3
      003236 8C 83            [24] 1041 	mov	dph,r4
      003238 12 3E 95         [24] 1042 	lcall	_malloc
      00323B AE 82            [24] 1043 	mov	r6,dpl
      00323D AF 83            [24] 1044 	mov	r7,dph
      00323F 90 13 BA         [24] 1045 	mov	dptr,#_main_buff0_ptr_131072_75
      003242 EE               [12] 1046 	mov	a,r6
      003243 F0               [24] 1047 	movx	@dptr,a
      003244 EF               [12] 1048 	mov	a,r7
      003245 A3               [24] 1049 	inc	dptr
      003246 F0               [24] 1050 	movx	@dptr,a
      003247 E4               [12] 1051 	clr	a
      003248 A3               [24] 1052 	inc	dptr
      003249 F0               [24] 1053 	movx	@dptr,a
      00324A                       1054 00111$:
                                   1055 ;	D:\Codeblocks\lab3_v2\main.c:174: buff0_base=buff0_ptr;       //saving base pointer location of buffer0 into buff0_base
      00324A 90 13 BA         [24] 1056 	mov	dptr,#_main_buff0_ptr_131072_75
      00324D E0               [24] 1057 	movx	a,@dptr
      00324E FD               [12] 1058 	mov	r5,a
      00324F A3               [24] 1059 	inc	dptr
      003250 E0               [24] 1060 	movx	a,@dptr
      003251 FE               [12] 1061 	mov	r6,a
      003252 A3               [24] 1062 	inc	dptr
      003253 E0               [24] 1063 	movx	a,@dptr
      003254 FF               [12] 1064 	mov	r7,a
      003255 90 13 BD         [24] 1065 	mov	dptr,#_main_buff0_base_131072_75
      003258 ED               [12] 1066 	mov	a,r5
      003259 F0               [24] 1067 	movx	@dptr,a
      00325A EE               [12] 1068 	mov	a,r6
      00325B A3               [24] 1069 	inc	dptr
      00325C F0               [24] 1070 	movx	@dptr,a
      00325D EF               [12] 1071 	mov	a,r7
      00325E A3               [24] 1072 	inc	dptr
      00325F F0               [24] 1073 	movx	@dptr,a
                                   1074 ;	D:\Codeblocks\lab3_v2\main.c:176: uint16_t buffer_op1 = buffer_size;
      003260 90 13 B6         [24] 1075 	mov	dptr,#_main_buffer_size_131072_75
      003263 E0               [24] 1076 	movx	a,@dptr
      003264 FB               [12] 1077 	mov	r3,a
      003265 A3               [24] 1078 	inc	dptr
      003266 E0               [24] 1079 	movx	a,@dptr
      003267 FC               [12] 1080 	mov	r4,a
                                   1081 ;	D:\Codeblocks\lab3_v2\main.c:185: buff1_ptr = (int *)malloc(buffer_size*sizeof(uint8_t));
      003268 8B 82            [24] 1082 	mov	dpl,r3
      00326A 8C 83            [24] 1083 	mov	dph,r4
      00326C C0 07            [24] 1084 	push	ar7
      00326E C0 06            [24] 1085 	push	ar6
      003270 C0 05            [24] 1086 	push	ar5
      003272 C0 04            [24] 1087 	push	ar4
      003274 C0 03            [24] 1088 	push	ar3
      003276 12 3E 95         [24] 1089 	lcall	_malloc
      003279 A9 82            [24] 1090 	mov	r1,dpl
      00327B AA 83            [24] 1091 	mov	r2,dph
      00327D D0 03            [24] 1092 	pop	ar3
      00327F D0 04            [24] 1093 	pop	ar4
      003281 D0 05            [24] 1094 	pop	ar5
      003283 D0 06            [24] 1095 	pop	ar6
      003285 D0 07            [24] 1096 	pop	ar7
      003287 8A 00            [24] 1097 	mov	ar0,r2
      003289 7A 00            [12] 1098 	mov	r2,#0x00
                                   1099 ;	D:\Codeblocks\lab3_v2\main.c:193: while(1)
      00328B 90 13 B8         [24] 1100 	mov	dptr,#_main_buffer0_size_131072_75
      00328E E0               [24] 1101 	movx	a,@dptr
      00328F F5 08            [12] 1102 	mov	_main_sloc0_1_0,a
      003291 A3               [24] 1103 	inc	dptr
      003292 E0               [24] 1104 	movx	a,@dptr
      003293 F5 09            [12] 1105 	mov	(_main_sloc0_1_0 + 1),a
      003295 8D 0A            [24] 1106 	mov	_main_sloc1_1_0,r5
      003297 8E 0B            [24] 1107 	mov	(_main_sloc1_1_0 + 1),r6
      003299 8F 0C            [24] 1108 	mov	(_main_sloc1_1_0 + 2),r7
      00329B EB               [12] 1109 	mov	a,r3
      00329C 2B               [12] 1110 	add	a,r3
      00329D FB               [12] 1111 	mov	r3,a
      00329E EC               [12] 1112 	mov	a,r4
      00329F 33               [12] 1113 	rlc	a
      0032A0 FC               [12] 1114 	mov	r4,a
      0032A1 74 A0            [12] 1115 	mov	a,#0xa0
      0032A3 C3               [12] 1116 	clr	c
      0032A4 9B               [12] 1117 	subb	a,r3
      0032A5 F5 22            [12] 1118 	mov	_main_sloc13_1_0,a
      0032A7 74 0F            [12] 1119 	mov	a,#0x0f
      0032A9 9C               [12] 1120 	subb	a,r4
      0032AA F5 23            [12] 1121 	mov	(_main_sloc13_1_0 + 1),a
      0032AC 85 08 0D         [24] 1122 	mov	_main_sloc2_1_0,_main_sloc0_1_0
      0032AF 85 09 0E         [24] 1123 	mov	(_main_sloc2_1_0 + 1),(_main_sloc0_1_0 + 1)
      0032B2 8D 0F            [24] 1124 	mov	_main_sloc3_1_0,r5
      0032B4 8E 10            [24] 1125 	mov	(_main_sloc3_1_0 + 1),r6
      0032B6 8F 11            [24] 1126 	mov	(_main_sloc3_1_0 + 2),r7
      0032B8 E5 08            [12] 1127 	mov	a,_main_sloc0_1_0
      0032BA 25 08            [12] 1128 	add	a,_main_sloc0_1_0
      0032BC F5 12            [12] 1129 	mov	_main_sloc4_1_0,a
      0032BE E5 09            [12] 1130 	mov	a,(_main_sloc0_1_0 + 1)
      0032C0 33               [12] 1131 	rlc	a
      0032C1 F5 13            [12] 1132 	mov	(_main_sloc4_1_0 + 1),a
      0032C3 8D 14            [24] 1133 	mov	_main_sloc5_1_0,r5
      0032C5 8E 15            [24] 1134 	mov	(_main_sloc5_1_0 + 1),r6
      0032C7 8F 16            [24] 1135 	mov	(_main_sloc5_1_0 + 2),r7
                                   1136 ;	1-genFromRTrack replaced	mov	_main_sloc6_1_0,#0x00
      0032C9 8A 17            [24] 1137 	mov	_main_sloc6_1_0,r2
      0032CB 75 18 02         [24] 1138 	mov	_main_sloc7_1_0,#0x02
      0032CE                       1139 00153$:
                                   1140 ;	D:\Codeblocks\lab3_v2\main.c:201: printf("\n\rEnter character:");
      0032CE C0 07            [24] 1141 	push	ar7
      0032D0 C0 06            [24] 1142 	push	ar6
      0032D2 C0 05            [24] 1143 	push	ar5
      0032D4 C0 02            [24] 1144 	push	ar2
      0032D6 C0 01            [24] 1145 	push	ar1
      0032D8 C0 00            [24] 1146 	push	ar0
      0032DA 74 FC            [12] 1147 	mov	a,#___str_4
      0032DC C0 E0            [24] 1148 	push	acc
      0032DE 74 4A            [12] 1149 	mov	a,#(___str_4 >> 8)
      0032E0 C0 E0            [24] 1150 	push	acc
      0032E2 74 80            [12] 1151 	mov	a,#0x80
      0032E4 C0 E0            [24] 1152 	push	acc
      0032E6 12 40 4C         [24] 1153 	lcall	_printf
      0032E9 15 81            [12] 1154 	dec	sp
      0032EB 15 81            [12] 1155 	dec	sp
      0032ED 15 81            [12] 1156 	dec	sp
                                   1157 ;	D:\Codeblocks\lab3_v2\main.c:202: ip_user=getchar();
      0032EF 12 30 8F         [24] 1158 	lcall	_getchar
      0032F2 AB 82            [24] 1159 	mov	r3,dpl
      0032F4 90 13 A8         [24] 1160 	mov	dptr,#_ip_user
      0032F7 EB               [12] 1161 	mov	a,r3
      0032F8 F0               [24] 1162 	movx	@dptr,a
                                   1163 ;	D:\Codeblocks\lab3_v2\main.c:203: putchar(ip_user);
      0032F9 7C 00            [12] 1164 	mov	r4,#0x00
      0032FB 8B 82            [24] 1165 	mov	dpl,r3
      0032FD 8C 83            [24] 1166 	mov	dph,r4
      0032FF 12 30 72         [24] 1167 	lcall	_putchar
      003302 D0 00            [24] 1168 	pop	ar0
      003304 D0 01            [24] 1169 	pop	ar1
      003306 D0 02            [24] 1170 	pop	ar2
      003308 D0 05            [24] 1171 	pop	ar5
      00330A D0 06            [24] 1172 	pop	ar6
      00330C D0 07            [24] 1173 	pop	ar7
                                   1174 ;	D:\Codeblocks\lab3_v2\main.c:205: if(ip_user>='a' && ip_user<='z')
      00330E 90 13 A8         [24] 1175 	mov	dptr,#_ip_user
      003311 E0               [24] 1176 	movx	a,@dptr
      003312 F5 19            [12] 1177 	mov	_main_sloc8_1_0,a
      003314 C3               [12] 1178 	clr	c
      003315 94 61            [12] 1179 	subb	a,#0x61
      003317 50 03            [24] 1180 	jnc	00316$
      003319 02 33 F7         [24] 1181 	ljmp	00149$
      00331C                       1182 00316$:
      00331C E5 19            [12] 1183 	mov	a,_main_sloc8_1_0
      00331E 24 85            [12] 1184 	add	a,#0xff - 0x7a
      003320 50 03            [24] 1185 	jnc	00317$
      003322 02 33 F7         [24] 1186 	ljmp	00149$
      003325                       1187 00317$:
                                   1188 ;	D:\Codeblocks\lab3_v2\main.c:207: if(user_alpha<=buffer0_size)
      003325 AB 17            [24] 1189 	mov	r3,_main_sloc6_1_0
      003327 7C 00            [12] 1190 	mov	r4,#0x00
      003329 C3               [12] 1191 	clr	c
      00332A E5 08            [12] 1192 	mov	a,_main_sloc0_1_0
      00332C 9B               [12] 1193 	subb	a,r3
      00332D E5 09            [12] 1194 	mov	a,(_main_sloc0_1_0 + 1)
      00332F 9C               [12] 1195 	subb	a,r4
      003330 50 03            [24] 1196 	jnc	00318$
      003332 02 33 BF         [24] 1197 	ljmp	00113$
      003335                       1198 00318$:
                                   1199 ;	D:\Codeblocks\lab3_v2\main.c:209: count_forenter++;
      003335 90 13 AA         [24] 1200 	mov	dptr,#_count_forenter
      003338 E0               [24] 1201 	movx	a,@dptr
      003339 24 01            [12] 1202 	add	a,#0x01
      00333B F0               [24] 1203 	movx	@dptr,a
      00333C A3               [24] 1204 	inc	dptr
      00333D E0               [24] 1205 	movx	a,@dptr
      00333E 34 00            [12] 1206 	addc	a,#0x00
      003340 F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	D:\Codeblocks\lab3_v2\main.c:210: *buff0_ptr=ip_user;
      003341 85 19 1A         [24] 1209 	mov	_main_sloc9_1_0,_main_sloc8_1_0
      003344 75 1B 00         [24] 1210 	mov	(_main_sloc9_1_0 + 1),#0x00
      003347 8D 82            [24] 1211 	mov	dpl,r5
      003349 8E 83            [24] 1212 	mov	dph,r6
      00334B 8F F0            [24] 1213 	mov	b,r7
      00334D E5 1A            [12] 1214 	mov	a,_main_sloc9_1_0
      00334F 12 3E 1E         [24] 1215 	lcall	__gptrput
      003352 A3               [24] 1216 	inc	dptr
      003353 E5 1B            [12] 1217 	mov	a,(_main_sloc9_1_0 + 1)
      003355 12 3E 1E         [24] 1218 	lcall	__gptrput
                                   1219 ;	D:\Codeblocks\lab3_v2\main.c:211: save_start_to_buff0 = buff0_base;
      003358 90 13 C0         [24] 1220 	mov	dptr,#_main_save_start_to_buff0_131072_75
      00335B E5 0A            [12] 1221 	mov	a,_main_sloc1_1_0
      00335D F0               [24] 1222 	movx	@dptr,a
      00335E E5 0B            [12] 1223 	mov	a,(_main_sloc1_1_0 + 1)
      003360 A3               [24] 1224 	inc	dptr
      003361 F0               [24] 1225 	movx	@dptr,a
      003362 E5 0C            [12] 1226 	mov	a,(_main_sloc1_1_0 + 2)
      003364 A3               [24] 1227 	inc	dptr
      003365 F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	D:\Codeblocks\lab3_v2\main.c:212: arr_to_store[user_alpha]=ip_user; //store all the characters in a array
      003366 E5 17            [12] 1230 	mov	a,_main_sloc6_1_0
      003368 24 01            [12] 1231 	add	a,#_main_arr_to_store_131072_75
      00336A F5 1C            [12] 1232 	mov	_main_sloc10_1_0,a
      00336C E4               [12] 1233 	clr	a
      00336D 34 14            [12] 1234 	addc	a,#(_main_arr_to_store_131072_75 >> 8)
      00336F F5 1D            [12] 1235 	mov	(_main_sloc10_1_0 + 1),a
      003371 90 13 A8         [24] 1236 	mov	dptr,#_ip_user
      003374 E0               [24] 1237 	movx	a,@dptr
      003375 85 1C 82         [24] 1238 	mov	dpl,_main_sloc10_1_0
      003378 85 1D 83         [24] 1239 	mov	dph,(_main_sloc10_1_0 + 1)
      00337B F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	D:\Codeblocks\lab3_v2\main.c:213: user_alpha++;   //counter to track number of characters entered
      00337C 05 17            [12] 1242 	inc	_main_sloc6_1_0
                                   1243 ;	D:\Codeblocks\lab3_v2\main.c:216: printf("\n\r Address:%p\t\t\t |\t\t\t %c",buff0_ptr,*buff0_ptr);
      00337E C0 07            [24] 1244 	push	ar7
      003380 C0 06            [24] 1245 	push	ar6
      003382 C0 05            [24] 1246 	push	ar5
      003384 C0 02            [24] 1247 	push	ar2
      003386 C0 01            [24] 1248 	push	ar1
      003388 C0 00            [24] 1249 	push	ar0
      00338A C0 1A            [24] 1250 	push	_main_sloc9_1_0
      00338C C0 1B            [24] 1251 	push	(_main_sloc9_1_0 + 1)
      00338E C0 05            [24] 1252 	push	ar5
      003390 C0 06            [24] 1253 	push	ar6
      003392 C0 07            [24] 1254 	push	ar7
      003394 74 0F            [12] 1255 	mov	a,#___str_5
      003396 C0 E0            [24] 1256 	push	acc
      003398 74 4B            [12] 1257 	mov	a,#(___str_5 >> 8)
      00339A C0 E0            [24] 1258 	push	acc
      00339C 74 80            [12] 1259 	mov	a,#0x80
      00339E C0 E0            [24] 1260 	push	acc
      0033A0 12 40 4C         [24] 1261 	lcall	_printf
      0033A3 E5 81            [12] 1262 	mov	a,sp
      0033A5 24 F8            [12] 1263 	add	a,#0xf8
      0033A7 F5 81            [12] 1264 	mov	sp,a
      0033A9 D0 00            [24] 1265 	pop	ar0
      0033AB D0 01            [24] 1266 	pop	ar1
      0033AD D0 02            [24] 1267 	pop	ar2
      0033AF D0 05            [24] 1268 	pop	ar5
      0033B1 D0 06            [24] 1269 	pop	ar6
      0033B3 D0 07            [24] 1270 	pop	ar7
                                   1271 ;	D:\Codeblocks\lab3_v2\main.c:217: buff0_ptr++;
      0033B5 74 02            [12] 1272 	mov	a,#0x02
      0033B7 2D               [12] 1273 	add	a,r5
      0033B8 FD               [12] 1274 	mov	r5,a
      0033B9 E4               [12] 1275 	clr	a
      0033BA 3E               [12] 1276 	addc	a,r6
      0033BB FE               [12] 1277 	mov	r6,a
      0033BC 02 32 CE         [24] 1278 	ljmp	00153$
      0033BF                       1279 00113$:
                                   1280 ;	D:\Codeblocks\lab3_v2\main.c:222: printf("Extra characters on screen %c",ip_user);
      0033BF AB 19            [24] 1281 	mov	r3,_main_sloc8_1_0
      0033C1 7C 00            [12] 1282 	mov	r4,#0x00
      0033C3 C0 07            [24] 1283 	push	ar7
      0033C5 C0 06            [24] 1284 	push	ar6
      0033C7 C0 05            [24] 1285 	push	ar5
      0033C9 C0 02            [24] 1286 	push	ar2
      0033CB C0 01            [24] 1287 	push	ar1
      0033CD C0 00            [24] 1288 	push	ar0
      0033CF C0 03            [24] 1289 	push	ar3
      0033D1 C0 04            [24] 1290 	push	ar4
      0033D3 74 28            [12] 1291 	mov	a,#___str_6
      0033D5 C0 E0            [24] 1292 	push	acc
      0033D7 74 4B            [12] 1293 	mov	a,#(___str_6 >> 8)
      0033D9 C0 E0            [24] 1294 	push	acc
      0033DB 74 80            [12] 1295 	mov	a,#0x80
      0033DD C0 E0            [24] 1296 	push	acc
      0033DF 12 40 4C         [24] 1297 	lcall	_printf
      0033E2 E5 81            [12] 1298 	mov	a,sp
      0033E4 24 FB            [12] 1299 	add	a,#0xfb
      0033E6 F5 81            [12] 1300 	mov	sp,a
      0033E8 D0 00            [24] 1301 	pop	ar0
      0033EA D0 01            [24] 1302 	pop	ar1
      0033EC D0 02            [24] 1303 	pop	ar2
      0033EE D0 05            [24] 1304 	pop	ar5
      0033F0 D0 06            [24] 1305 	pop	ar6
      0033F2 D0 07            [24] 1306 	pop	ar7
      0033F4 02 32 CE         [24] 1307 	ljmp	00153$
      0033F7                       1308 00149$:
                                   1309 ;	D:\Codeblocks\lab3_v2\main.c:232: else if(ip_user=='+')
      0033F7 90 13 A8         [24] 1310 	mov	dptr,#_ip_user
      0033FA E0               [24] 1311 	movx	a,@dptr
      0033FB F5 1C            [12] 1312 	mov	_main_sloc10_1_0,a
      0033FD 74 2B            [12] 1313 	mov	a,#0x2b
      0033FF B5 1C 02         [24] 1314 	cjne	a,_main_sloc10_1_0,00319$
      003402 80 03            [24] 1315 	sjmp	00320$
      003404                       1316 00319$:
      003404 02 35 6D         [24] 1317 	ljmp	00146$
      003407                       1318 00320$:
                                   1319 ;	D:\Codeblocks\lab3_v2\main.c:235: do
      003407 E5 18            [12] 1320 	mov	a,_main_sloc7_1_0
      003409 F5 1A            [12] 1321 	mov	_main_sloc9_1_0,a
      00340B 75 F0 02         [24] 1322 	mov	b,#0x02
      00340E A4               [48] 1323 	mul	ab
      00340F F5 1E            [12] 1324 	mov	_main_sloc11_1_0,a
      003411 85 F0 1F         [24] 1325 	mov	(_main_sloc11_1_0 + 1),b
      003414                       1326 00116$:
                                   1327 ;	D:\Codeblocks\lab3_v2\main.c:237: count_forenter++;
      003414 90 13 AA         [24] 1328 	mov	dptr,#_count_forenter
      003417 E0               [24] 1329 	movx	a,@dptr
      003418 24 01            [12] 1330 	add	a,#0x01
      00341A F0               [24] 1331 	movx	@dptr,a
      00341B A3               [24] 1332 	inc	dptr
      00341C E0               [24] 1333 	movx	a,@dptr
      00341D 34 00            [12] 1334 	addc	a,#0x00
      00341F F0               [24] 1335 	movx	@dptr,a
                                   1336 ;	D:\Codeblocks\lab3_v2\main.c:238: printf("\n\rEnter new buffer size between 30 to 300 bytes");
      003420 C0 07            [24] 1337 	push	ar7
      003422 C0 06            [24] 1338 	push	ar6
      003424 C0 05            [24] 1339 	push	ar5
      003426 C0 02            [24] 1340 	push	ar2
      003428 C0 01            [24] 1341 	push	ar1
      00342A C0 00            [24] 1342 	push	ar0
      00342C 74 46            [12] 1343 	mov	a,#___str_7
      00342E C0 E0            [24] 1344 	push	acc
      003430 74 4B            [12] 1345 	mov	a,#(___str_7 >> 8)
      003432 C0 E0            [24] 1346 	push	acc
      003434 74 80            [12] 1347 	mov	a,#0x80
      003436 C0 E0            [24] 1348 	push	acc
      003438 12 40 4C         [24] 1349 	lcall	_printf
      00343B 15 81            [12] 1350 	dec	sp
      00343D 15 81            [12] 1351 	dec	sp
      00343F 15 81            [12] 1352 	dec	sp
                                   1353 ;	D:\Codeblocks\lab3_v2\main.c:239: buffer_input();
      003441 12 30 9D         [24] 1354 	lcall	_buffer_input
      003444 D0 00            [24] 1355 	pop	ar0
      003446 D0 01            [24] 1356 	pop	ar1
      003448 D0 02            [24] 1357 	pop	ar2
      00344A D0 05            [24] 1358 	pop	ar5
      00344C D0 06            [24] 1359 	pop	ar6
      00344E D0 07            [24] 1360 	pop	ar7
                                   1361 ;	D:\Codeblocks\lab3_v2\main.c:240: buffer_size = input_size;
      003450 90 13 A3         [24] 1362 	mov	dptr,#_input_size
      003453 E0               [24] 1363 	movx	a,@dptr
      003454 FB               [12] 1364 	mov	r3,a
      003455 A3               [24] 1365 	inc	dptr
      003456 E0               [24] 1366 	movx	a,@dptr
      003457 FC               [12] 1367 	mov	r4,a
      003458 90 13 B6         [24] 1368 	mov	dptr,#_main_buffer_size_131072_75
      00345B EB               [12] 1369 	mov	a,r3
      00345C F0               [24] 1370 	movx	@dptr,a
      00345D EC               [12] 1371 	mov	a,r4
      00345E A3               [24] 1372 	inc	dptr
      00345F F0               [24] 1373 	movx	@dptr,a
                                   1374 ;	D:\Codeblocks\lab3_v2\main.c:241: arr_forfree_space[count] = buffer_size;
      003460 E5 1E            [12] 1375 	mov	a,_main_sloc11_1_0
      003462 24 C5            [12] 1376 	add	a,#_main_arr_forfree_space_131072_75
      003464 F5 82            [12] 1377 	mov	dpl,a
      003466 E5 1F            [12] 1378 	mov	a,(_main_sloc11_1_0 + 1)
      003468 34 13            [12] 1379 	addc	a,#(_main_arr_forfree_space_131072_75 >> 8)
      00346A F5 83            [12] 1380 	mov	dph,a
      00346C EB               [12] 1381 	mov	a,r3
      00346D F0               [24] 1382 	movx	@dptr,a
      00346E EC               [12] 1383 	mov	a,r4
      00346F A3               [24] 1384 	inc	dptr
      003470 F0               [24] 1385 	movx	@dptr,a
                                   1386 ;	D:\Codeblocks\lab3_v2\main.c:242: buffer_4comp +=buffer_size;
      003471 90 13 B6         [24] 1387 	mov	dptr,#_main_buffer_size_131072_75
      003474 E0               [24] 1388 	movx	a,@dptr
      003475 F5 20            [12] 1389 	mov	_main_sloc12_1_0,a
      003477 A3               [24] 1390 	inc	dptr
      003478 E0               [24] 1391 	movx	a,@dptr
      003479 F5 21            [12] 1392 	mov	(_main_sloc12_1_0 + 1),a
      00347B 90 13 C3         [24] 1393 	mov	dptr,#_main_buffer_4comp_131072_75
      00347E E0               [24] 1394 	movx	a,@dptr
      00347F FB               [12] 1395 	mov	r3,a
      003480 A3               [24] 1396 	inc	dptr
      003481 E0               [24] 1397 	movx	a,@dptr
      003482 FC               [12] 1398 	mov	r4,a
      003483 90 13 C3         [24] 1399 	mov	dptr,#_main_buffer_4comp_131072_75
      003486 E5 20            [12] 1400 	mov	a,_main_sloc12_1_0
      003488 2B               [12] 1401 	add	a,r3
      003489 F0               [24] 1402 	movx	@dptr,a
      00348A E5 21            [12] 1403 	mov	a,(_main_sloc12_1_0 + 1)
      00348C 3C               [12] 1404 	addc	a,r4
      00348D A3               [24] 1405 	inc	dptr
      00348E F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	D:\Codeblocks\lab3_v2\main.c:243: }while(buffer_size<30 || buffer_size>300);
      00348F C3               [12] 1408 	clr	c
      003490 E5 20            [12] 1409 	mov	a,_main_sloc12_1_0
      003492 94 1E            [12] 1410 	subb	a,#0x1e
      003494 E5 21            [12] 1411 	mov	a,(_main_sloc12_1_0 + 1)
      003496 94 00            [12] 1412 	subb	a,#0x00
      003498 50 03            [24] 1413 	jnc	00321$
      00349A 02 34 14         [24] 1414 	ljmp	00116$
      00349D                       1415 00321$:
      00349D C3               [12] 1416 	clr	c
      00349E 74 2C            [12] 1417 	mov	a,#0x2c
      0034A0 95 20            [12] 1418 	subb	a,_main_sloc12_1_0
      0034A2 74 01            [12] 1419 	mov	a,#0x01
      0034A4 95 21            [12] 1420 	subb	a,(_main_sloc12_1_0 + 1)
      0034A6 50 03            [24] 1421 	jnc	00322$
      0034A8 02 34 14         [24] 1422 	ljmp	00116$
      0034AB                       1423 00322$:
                                   1424 ;	D:\Codeblocks\lab3_v2\main.c:245: buffptr_forplus[count] = (int *)malloc(buffer_size*sizeof(uint8_t));
      0034AB C0 01            [24] 1425 	push	ar1
      0034AD C0 00            [24] 1426 	push	ar0
      0034AF C0 02            [24] 1427 	push	ar2
      0034B1 E5 1A            [12] 1428 	mov	a,_main_sloc9_1_0
      0034B3 75 F0 03         [24] 1429 	mov	b,#0x03
      0034B6 A4               [48] 1430 	mul	ab
      0034B7 24 1F            [12] 1431 	add	a,#_main_buffptr_forplus_131072_75
      0034B9 F9               [12] 1432 	mov	r1,a
      0034BA 74 14            [12] 1433 	mov	a,#(_main_buffptr_forplus_131072_75 >> 8)
      0034BC 35 F0            [12] 1434 	addc	a,b
      0034BE FA               [12] 1435 	mov	r2,a
      0034BF 85 20 82         [24] 1436 	mov	dpl,_main_sloc12_1_0
      0034C2 85 21 83         [24] 1437 	mov	dph,(_main_sloc12_1_0 + 1)
      0034C5 C0 07            [24] 1438 	push	ar7
      0034C7 C0 06            [24] 1439 	push	ar6
      0034C9 C0 05            [24] 1440 	push	ar5
      0034CB C0 02            [24] 1441 	push	ar2
      0034CD C0 01            [24] 1442 	push	ar1
      0034CF 12 3E 95         [24] 1443 	lcall	_malloc
      0034D2 A8 82            [24] 1444 	mov	r0,dpl
      0034D4 AC 83            [24] 1445 	mov	r4,dph
      0034D6 D0 01            [24] 1446 	pop	ar1
      0034D8 D0 02            [24] 1447 	pop	ar2
      0034DA 7B 00            [12] 1448 	mov	r3,#0x00
      0034DC 89 82            [24] 1449 	mov	dpl,r1
      0034DE 8A 83            [24] 1450 	mov	dph,r2
      0034E0 E8               [12] 1451 	mov	a,r0
      0034E1 F0               [24] 1452 	movx	@dptr,a
      0034E2 EC               [12] 1453 	mov	a,r4
      0034E3 A3               [24] 1454 	inc	dptr
      0034E4 F0               [24] 1455 	movx	@dptr,a
      0034E5 EB               [12] 1456 	mov	a,r3
      0034E6 A3               [24] 1457 	inc	dptr
      0034E7 F0               [24] 1458 	movx	@dptr,a
                                   1459 ;	D:\Codeblocks\lab3_v2\main.c:246: printf("\n\r%p \n",buffptr_forplus[count]);
      0034E8 C0 02            [24] 1460 	push	ar2
      0034EA C0 01            [24] 1461 	push	ar1
      0034EC C0 00            [24] 1462 	push	ar0
      0034EE C0 00            [24] 1463 	push	ar0
      0034F0 C0 04            [24] 1464 	push	ar4
      0034F2 C0 03            [24] 1465 	push	ar3
      0034F4 74 76            [12] 1466 	mov	a,#___str_8
      0034F6 C0 E0            [24] 1467 	push	acc
      0034F8 74 4B            [12] 1468 	mov	a,#(___str_8 >> 8)
      0034FA C0 E0            [24] 1469 	push	acc
      0034FC 74 80            [12] 1470 	mov	a,#0x80
      0034FE C0 E0            [24] 1471 	push	acc
      003500 12 40 4C         [24] 1472 	lcall	_printf
      003503 E5 81            [12] 1473 	mov	a,sp
      003505 24 FA            [12] 1474 	add	a,#0xfa
      003507 F5 81            [12] 1475 	mov	sp,a
      003509 D0 00            [24] 1476 	pop	ar0
      00350B D0 01            [24] 1477 	pop	ar1
      00350D D0 02            [24] 1478 	pop	ar2
      00350F D0 05            [24] 1479 	pop	ar5
      003511 D0 06            [24] 1480 	pop	ar6
      003513 D0 07            [24] 1481 	pop	ar7
                                   1482 ;	D:\Codeblocks\lab3_v2\main.c:249: count++;
      003515 E5 1A            [12] 1483 	mov	a,_main_sloc9_1_0
      003517 04               [12] 1484 	inc	a
      003518 F5 18            [12] 1485 	mov	_main_sloc7_1_0,a
                                   1486 ;	D:\Codeblocks\lab3_v2\main.c:250: if(buffer_4comp>(4000-(2*buffer_op1)))
      00351A 90 13 C3         [24] 1487 	mov	dptr,#_main_buffer_4comp_131072_75
      00351D E0               [24] 1488 	movx	a,@dptr
      00351E FB               [12] 1489 	mov	r3,a
      00351F A3               [24] 1490 	inc	dptr
      003520 E0               [24] 1491 	movx	a,@dptr
      003521 FC               [12] 1492 	mov	r4,a
      003522 C3               [12] 1493 	clr	c
      003523 E5 22            [12] 1494 	mov	a,_main_sloc13_1_0
      003525 9B               [12] 1495 	subb	a,r3
      003526 E5 23            [12] 1496 	mov	a,(_main_sloc13_1_0 + 1)
      003528 9C               [12] 1497 	subb	a,r4
      003529 D0 02            [24] 1498 	pop	ar2
      00352B D0 00            [24] 1499 	pop	ar0
      00352D D0 01            [24] 1500 	pop	ar1
      00352F 40 03            [24] 1501 	jc	00323$
      003531 02 32 CE         [24] 1502 	ljmp	00153$
      003534                       1503 00323$:
                                   1504 ;	D:\Codeblocks\lab3_v2\main.c:252: printf("Malloc Failed");
      003534 C0 07            [24] 1505 	push	ar7
      003536 C0 06            [24] 1506 	push	ar6
      003538 C0 05            [24] 1507 	push	ar5
      00353A C0 02            [24] 1508 	push	ar2
      00353C C0 01            [24] 1509 	push	ar1
      00353E C0 00            [24] 1510 	push	ar0
      003540 74 CB            [12] 1511 	mov	a,#___str_2
      003542 C0 E0            [24] 1512 	push	acc
      003544 74 4A            [12] 1513 	mov	a,#(___str_2 >> 8)
      003546 C0 E0            [24] 1514 	push	acc
      003548 74 80            [12] 1515 	mov	a,#0x80
      00354A C0 E0            [24] 1516 	push	acc
      00354C 12 40 4C         [24] 1517 	lcall	_printf
      00354F 15 81            [12] 1518 	dec	sp
      003551 15 81            [12] 1519 	dec	sp
      003553 15 81            [12] 1520 	dec	sp
                                   1521 ;	D:\Codeblocks\lab3_v2\main.c:253: free(buffptr_forplus);
      003555 90 14 1F         [24] 1522 	mov	dptr,#_main_buffptr_forplus_131072_75
      003558 75 F0 00         [24] 1523 	mov	b,#0x00
      00355B 12 3B A7         [24] 1524 	lcall	_free
      00355E D0 00            [24] 1525 	pop	ar0
      003560 D0 01            [24] 1526 	pop	ar1
      003562 D0 02            [24] 1527 	pop	ar2
      003564 D0 05            [24] 1528 	pop	ar5
      003566 D0 06            [24] 1529 	pop	ar6
      003568 D0 07            [24] 1530 	pop	ar7
      00356A 02 32 CE         [24] 1531 	ljmp	00153$
      00356D                       1532 00146$:
                                   1533 ;	D:\Codeblocks\lab3_v2\main.c:261: else if(ip_user=='-')
      00356D 74 2D            [12] 1534 	mov	a,#0x2d
      00356F B5 1C 02         [24] 1535 	cjne	a,_main_sloc10_1_0,00324$
      003572 80 03            [24] 1536 	sjmp	00325$
      003574                       1537 00324$:
      003574 02 36 A1         [24] 1538 	ljmp	00143$
      003577                       1539 00325$:
                                   1540 ;	D:\Codeblocks\lab3_v2\main.c:263: count_forenter++;
      003577 90 13 AA         [24] 1541 	mov	dptr,#_count_forenter
      00357A E0               [24] 1542 	movx	a,@dptr
      00357B 24 01            [12] 1543 	add	a,#0x01
      00357D F0               [24] 1544 	movx	@dptr,a
      00357E A3               [24] 1545 	inc	dptr
      00357F E0               [24] 1546 	movx	a,@dptr
      003580 34 00            [12] 1547 	addc	a,#0x00
      003582 F0               [24] 1548 	movx	@dptr,a
                                   1549 ;	D:\Codeblocks\lab3_v2\main.c:265: printf("\n\rEnter valid buffer number");
      003583 C0 07            [24] 1550 	push	ar7
      003585 C0 06            [24] 1551 	push	ar6
      003587 C0 05            [24] 1552 	push	ar5
      003589 C0 02            [24] 1553 	push	ar2
      00358B C0 01            [24] 1554 	push	ar1
      00358D C0 00            [24] 1555 	push	ar0
      00358F 74 7D            [12] 1556 	mov	a,#___str_9
      003591 C0 E0            [24] 1557 	push	acc
      003593 74 4B            [12] 1558 	mov	a,#(___str_9 >> 8)
      003595 C0 E0            [24] 1559 	push	acc
      003597 74 80            [12] 1560 	mov	a,#0x80
      003599 C0 E0            [24] 1561 	push	acc
      00359B 12 40 4C         [24] 1562 	lcall	_printf
      00359E 15 81            [12] 1563 	dec	sp
      0035A0 15 81            [12] 1564 	dec	sp
      0035A2 15 81            [12] 1565 	dec	sp
                                   1566 ;	D:\Codeblocks\lab3_v2\main.c:266: buffer_input();
      0035A4 12 30 9D         [24] 1567 	lcall	_buffer_input
      0035A7 D0 00            [24] 1568 	pop	ar0
      0035A9 D0 01            [24] 1569 	pop	ar1
      0035AB D0 02            [24] 1570 	pop	ar2
      0035AD D0 05            [24] 1571 	pop	ar5
      0035AF D0 06            [24] 1572 	pop	ar6
      0035B1 D0 07            [24] 1573 	pop	ar7
                                   1574 ;	D:\Codeblocks\lab3_v2\main.c:267: valid_num = input_size;
      0035B3 90 13 A3         [24] 1575 	mov	dptr,#_input_size
      0035B6 E0               [24] 1576 	movx	a,@dptr
      0035B7 FB               [12] 1577 	mov	r3,a
      0035B8 A3               [24] 1578 	inc	dptr
      0035B9 E0               [24] 1579 	movx	a,@dptr
      0035BA FC               [12] 1580 	mov	r4,a
      0035BB 90 14 79         [24] 1581 	mov	dptr,#_main_valid_num_131072_75
      0035BE EB               [12] 1582 	mov	a,r3
      0035BF F0               [24] 1583 	movx	@dptr,a
                                   1584 ;	D:\Codeblocks\lab3_v2\main.c:269: if(valid_num<=count)
      0035C0 C3               [12] 1585 	clr	c
      0035C1 E5 18            [12] 1586 	mov	a,_main_sloc7_1_0
      0035C3 9B               [12] 1587 	subb	a,r3
      0035C4 50 03            [24] 1588 	jnc	00326$
      0035C6 02 36 71         [24] 1589 	ljmp	00122$
      0035C9                       1590 00326$:
                                   1591 ;	D:\Codeblocks\lab3_v2\main.c:271: printf("\n\rvalid number");
      0035C9 C0 01            [24] 1592 	push	ar1
      0035CB C0 00            [24] 1593 	push	ar0
      0035CD C0 02            [24] 1594 	push	ar2
      0035CF C0 07            [24] 1595 	push	ar7
      0035D1 C0 06            [24] 1596 	push	ar6
      0035D3 C0 05            [24] 1597 	push	ar5
      0035D5 C0 02            [24] 1598 	push	ar2
      0035D7 C0 01            [24] 1599 	push	ar1
      0035D9 C0 00            [24] 1600 	push	ar0
      0035DB 74 99            [12] 1601 	mov	a,#___str_10
      0035DD C0 E0            [24] 1602 	push	acc
      0035DF 74 4B            [12] 1603 	mov	a,#(___str_10 >> 8)
      0035E1 C0 E0            [24] 1604 	push	acc
      0035E3 74 80            [12] 1605 	mov	a,#0x80
      0035E5 C0 E0            [24] 1606 	push	acc
      0035E7 12 40 4C         [24] 1607 	lcall	_printf
      0035EA 15 81            [12] 1608 	dec	sp
      0035EC 15 81            [12] 1609 	dec	sp
      0035EE 15 81            [12] 1610 	dec	sp
      0035F0 D0 00            [24] 1611 	pop	ar0
      0035F2 D0 01            [24] 1612 	pop	ar1
      0035F4 D0 02            [24] 1613 	pop	ar2
                                   1614 ;	D:\Codeblocks\lab3_v2\main.c:272: free(buffptr_forplus[valid_num]);
      0035F6 90 14 79         [24] 1615 	mov	dptr,#_main_valid_num_131072_75
      0035F9 E0               [24] 1616 	movx	a,@dptr
      0035FA 75 F0 03         [24] 1617 	mov	b,#0x03
      0035FD A4               [48] 1618 	mul	ab
      0035FE 24 1F            [12] 1619 	add	a,#_main_buffptr_forplus_131072_75
      003600 FB               [12] 1620 	mov	r3,a
      003601 74 14            [12] 1621 	mov	a,#(_main_buffptr_forplus_131072_75 >> 8)
      003603 35 F0            [12] 1622 	addc	a,b
      003605 FC               [12] 1623 	mov	r4,a
      003606 8B 82            [24] 1624 	mov	dpl,r3
      003608 8C 83            [24] 1625 	mov	dph,r4
      00360A E0               [24] 1626 	movx	a,@dptr
      00360B F8               [12] 1627 	mov	r0,a
      00360C A3               [24] 1628 	inc	dptr
      00360D E0               [24] 1629 	movx	a,@dptr
      00360E F9               [12] 1630 	mov	r1,a
      00360F A3               [24] 1631 	inc	dptr
      003610 E0               [24] 1632 	movx	a,@dptr
      003611 FA               [12] 1633 	mov	r2,a
      003612 88 82            [24] 1634 	mov	dpl,r0
      003614 89 83            [24] 1635 	mov	dph,r1
      003616 8A F0            [24] 1636 	mov	b,r2
      003618 C0 04            [24] 1637 	push	ar4
      00361A C0 03            [24] 1638 	push	ar3
      00361C C0 02            [24] 1639 	push	ar2
      00361E C0 01            [24] 1640 	push	ar1
      003620 C0 00            [24] 1641 	push	ar0
      003622 12 3B A7         [24] 1642 	lcall	_free
      003625 D0 00            [24] 1643 	pop	ar0
      003627 D0 01            [24] 1644 	pop	ar1
      003629 D0 02            [24] 1645 	pop	ar2
      00362B D0 03            [24] 1646 	pop	ar3
      00362D D0 04            [24] 1647 	pop	ar4
                                   1648 ;	D:\Codeblocks\lab3_v2\main.c:273: printf("\n\r%p \n",buffptr_forplus[valid_num]);
      00362F 8B 82            [24] 1649 	mov	dpl,r3
      003631 8C 83            [24] 1650 	mov	dph,r4
      003633 E0               [24] 1651 	movx	a,@dptr
      003634 FB               [12] 1652 	mov	r3,a
      003635 A3               [24] 1653 	inc	dptr
      003636 E0               [24] 1654 	movx	a,@dptr
      003637 FC               [12] 1655 	mov	r4,a
      003638 A3               [24] 1656 	inc	dptr
      003639 E0               [24] 1657 	movx	a,@dptr
      00363A FA               [12] 1658 	mov	r2,a
      00363B C0 02            [24] 1659 	push	ar2
      00363D C0 01            [24] 1660 	push	ar1
      00363F C0 00            [24] 1661 	push	ar0
      003641 C0 03            [24] 1662 	push	ar3
      003643 C0 04            [24] 1663 	push	ar4
      003645 C0 02            [24] 1664 	push	ar2
      003647 74 76            [12] 1665 	mov	a,#___str_8
      003649 C0 E0            [24] 1666 	push	acc
      00364B 74 4B            [12] 1667 	mov	a,#(___str_8 >> 8)
      00364D C0 E0            [24] 1668 	push	acc
      00364F 74 80            [12] 1669 	mov	a,#0x80
      003651 C0 E0            [24] 1670 	push	acc
      003653 12 40 4C         [24] 1671 	lcall	_printf
      003656 E5 81            [12] 1672 	mov	a,sp
      003658 24 FA            [12] 1673 	add	a,#0xfa
      00365A F5 81            [12] 1674 	mov	sp,a
      00365C D0 00            [24] 1675 	pop	ar0
      00365E D0 01            [24] 1676 	pop	ar1
      003660 D0 02            [24] 1677 	pop	ar2
      003662 D0 05            [24] 1678 	pop	ar5
      003664 D0 06            [24] 1679 	pop	ar6
      003666 D0 07            [24] 1680 	pop	ar7
      003668 D0 02            [24] 1681 	pop	ar2
      00366A D0 00            [24] 1682 	pop	ar0
      00366C D0 01            [24] 1683 	pop	ar1
      00366E 02 32 CE         [24] 1684 	ljmp	00153$
      003671                       1685 00122$:
                                   1686 ;	D:\Codeblocks\lab3_v2\main.c:277: printf("\n\rInvalid number");
      003671 C0 07            [24] 1687 	push	ar7
      003673 C0 06            [24] 1688 	push	ar6
      003675 C0 05            [24] 1689 	push	ar5
      003677 C0 02            [24] 1690 	push	ar2
      003679 C0 01            [24] 1691 	push	ar1
      00367B C0 00            [24] 1692 	push	ar0
      00367D 74 A8            [12] 1693 	mov	a,#___str_11
      00367F C0 E0            [24] 1694 	push	acc
      003681 74 4B            [12] 1695 	mov	a,#(___str_11 >> 8)
      003683 C0 E0            [24] 1696 	push	acc
      003685 74 80            [12] 1697 	mov	a,#0x80
      003687 C0 E0            [24] 1698 	push	acc
      003689 12 40 4C         [24] 1699 	lcall	_printf
      00368C 15 81            [12] 1700 	dec	sp
      00368E 15 81            [12] 1701 	dec	sp
      003690 15 81            [12] 1702 	dec	sp
      003692 D0 00            [24] 1703 	pop	ar0
      003694 D0 01            [24] 1704 	pop	ar1
      003696 D0 02            [24] 1705 	pop	ar2
      003698 D0 05            [24] 1706 	pop	ar5
      00369A D0 06            [24] 1707 	pop	ar6
      00369C D0 07            [24] 1708 	pop	ar7
      00369E 02 32 CE         [24] 1709 	ljmp	00153$
      0036A1                       1710 00143$:
                                   1711 ;	D:\Codeblocks\lab3_v2\main.c:285: else if(ip_user=='?')
      0036A1 74 3F            [12] 1712 	mov	a,#0x3f
      0036A3 B5 1C 02         [24] 1713 	cjne	a,_main_sloc10_1_0,00327$
      0036A6 80 03            [24] 1714 	sjmp	00328$
      0036A8                       1715 00327$:
      0036A8 02 39 FA         [24] 1716 	ljmp	00140$
      0036AB                       1717 00328$:
                                   1718 ;	D:\Codeblocks\lab3_v2\main.c:287: DEBUGPORT(0x55);
      0036AB 75 82 55         [24] 1719 	mov	dpl,#0x55
      0036AE C0 07            [24] 1720 	push	ar7
      0036B0 C0 06            [24] 1721 	push	ar6
      0036B2 C0 05            [24] 1722 	push	ar5
      0036B4 C0 02            [24] 1723 	push	ar2
      0036B6 C0 01            [24] 1724 	push	ar1
      0036B8 C0 00            [24] 1725 	push	ar0
      0036BA 12 30 62         [24] 1726 	lcall	_dataout
      0036BD D0 00            [24] 1727 	pop	ar0
      0036BF D0 01            [24] 1728 	pop	ar1
      0036C1 D0 02            [24] 1729 	pop	ar2
      0036C3 D0 05            [24] 1730 	pop	ar5
      0036C5 D0 06            [24] 1731 	pop	ar6
      0036C7 D0 07            [24] 1732 	pop	ar7
                                   1733 ;	D:\Codeblocks\lab3_v2\main.c:288: if(user_alpha<=buffer0_size)
      0036C9 AB 17            [24] 1734 	mov	r3,_main_sloc6_1_0
      0036CB 7C 00            [12] 1735 	mov	r4,#0x00
      0036CD C3               [12] 1736 	clr	c
      0036CE E5 0D            [12] 1737 	mov	a,_main_sloc2_1_0
      0036D0 9B               [12] 1738 	subb	a,r3
      0036D1 E5 0E            [12] 1739 	mov	a,(_main_sloc2_1_0 + 1)
      0036D3 9C               [12] 1740 	subb	a,r4
      0036D4 50 03            [24] 1741 	jnc	00329$
      0036D6 02 39 C4         [24] 1742 	ljmp	00127$
      0036D9                       1743 00329$:
                                   1744 ;	D:\Codeblocks\lab3_v2\main.c:290: count_forenter++;
      0036D9 C0 05            [24] 1745 	push	ar5
      0036DB C0 06            [24] 1746 	push	ar6
      0036DD C0 07            [24] 1747 	push	ar7
      0036DF 90 13 AA         [24] 1748 	mov	dptr,#_count_forenter
      0036E2 E0               [24] 1749 	movx	a,@dptr
      0036E3 24 01            [12] 1750 	add	a,#0x01
      0036E5 F0               [24] 1751 	movx	@dptr,a
      0036E6 A3               [24] 1752 	inc	dptr
      0036E7 E0               [24] 1753 	movx	a,@dptr
      0036E8 34 00            [12] 1754 	addc	a,#0x00
      0036EA F0               [24] 1755 	movx	@dptr,a
                                   1756 ;	D:\Codeblocks\lab3_v2\main.c:291: printf("\n\rThe total count is: %d",count_forenter);
      0036EB C0 07            [24] 1757 	push	ar7
      0036ED C0 06            [24] 1758 	push	ar6
      0036EF C0 05            [24] 1759 	push	ar5
      0036F1 C0 02            [24] 1760 	push	ar2
      0036F3 C0 01            [24] 1761 	push	ar1
      0036F5 C0 00            [24] 1762 	push	ar0
      0036F7 90 13 AA         [24] 1763 	mov	dptr,#_count_forenter
      0036FA E0               [24] 1764 	movx	a,@dptr
      0036FB C0 E0            [24] 1765 	push	acc
      0036FD A3               [24] 1766 	inc	dptr
      0036FE E0               [24] 1767 	movx	a,@dptr
      0036FF C0 E0            [24] 1768 	push	acc
      003701 74 B9            [12] 1769 	mov	a,#___str_12
      003703 C0 E0            [24] 1770 	push	acc
      003705 74 4B            [12] 1771 	mov	a,#(___str_12 >> 8)
      003707 C0 E0            [24] 1772 	push	acc
      003709 74 80            [12] 1773 	mov	a,#0x80
      00370B C0 E0            [24] 1774 	push	acc
      00370D 12 40 4C         [24] 1775 	lcall	_printf
      003710 E5 81            [12] 1776 	mov	a,sp
      003712 24 FB            [12] 1777 	add	a,#0xfb
      003714 F5 81            [12] 1778 	mov	sp,a
                                   1779 ;	D:\Codeblocks\lab3_v2\main.c:292: printf("\n\r Buffer0 Start Address %p",buff0_base);
      003716 90 13 BD         [24] 1780 	mov	dptr,#_main_buff0_base_131072_75
      003719 E0               [24] 1781 	movx	a,@dptr
      00371A C0 E0            [24] 1782 	push	acc
      00371C A3               [24] 1783 	inc	dptr
      00371D E0               [24] 1784 	movx	a,@dptr
      00371E C0 E0            [24] 1785 	push	acc
      003720 A3               [24] 1786 	inc	dptr
      003721 E0               [24] 1787 	movx	a,@dptr
      003722 C0 E0            [24] 1788 	push	acc
      003724 74 D2            [12] 1789 	mov	a,#___str_13
      003726 C0 E0            [24] 1790 	push	acc
      003728 74 4B            [12] 1791 	mov	a,#(___str_13 >> 8)
      00372A C0 E0            [24] 1792 	push	acc
      00372C 74 80            [12] 1793 	mov	a,#0x80
      00372E C0 E0            [24] 1794 	push	acc
      003730 12 40 4C         [24] 1795 	lcall	_printf
      003733 E5 81            [12] 1796 	mov	a,sp
      003735 24 FA            [12] 1797 	add	a,#0xfa
      003737 F5 81            [12] 1798 	mov	sp,a
      003739 D0 00            [24] 1799 	pop	ar0
      00373B D0 01            [24] 1800 	pop	ar1
      00373D D0 02            [24] 1801 	pop	ar2
      00373F D0 05            [24] 1802 	pop	ar5
      003741 D0 06            [24] 1803 	pop	ar6
      003743 D0 07            [24] 1804 	pop	ar7
                                   1805 ;	D:\Codeblocks\lab3_v2\main.c:293: printf("\n\r Buffer0 End Address is %p",(buff0_base+buffer0_size));
      003745 E5 12            [12] 1806 	mov	a,_main_sloc4_1_0
      003747 25 0F            [12] 1807 	add	a,_main_sloc3_1_0
      003749 FB               [12] 1808 	mov	r3,a
      00374A E5 13            [12] 1809 	mov	a,(_main_sloc4_1_0 + 1)
      00374C 35 10            [12] 1810 	addc	a,(_main_sloc3_1_0 + 1)
      00374E FC               [12] 1811 	mov	r4,a
      00374F AF 11            [24] 1812 	mov	r7,(_main_sloc3_1_0 + 2)
      003751 C0 07            [24] 1813 	push	ar7
      003753 C0 06            [24] 1814 	push	ar6
      003755 C0 05            [24] 1815 	push	ar5
      003757 C0 02            [24] 1816 	push	ar2
      003759 C0 01            [24] 1817 	push	ar1
      00375B C0 00            [24] 1818 	push	ar0
      00375D C0 03            [24] 1819 	push	ar3
      00375F C0 04            [24] 1820 	push	ar4
      003761 C0 07            [24] 1821 	push	ar7
      003763 74 EE            [12] 1822 	mov	a,#___str_14
      003765 C0 E0            [24] 1823 	push	acc
      003767 74 4B            [12] 1824 	mov	a,#(___str_14 >> 8)
      003769 C0 E0            [24] 1825 	push	acc
      00376B 74 80            [12] 1826 	mov	a,#0x80
      00376D C0 E0            [24] 1827 	push	acc
      00376F 12 40 4C         [24] 1828 	lcall	_printf
      003772 E5 81            [12] 1829 	mov	a,sp
      003774 24 FA            [12] 1830 	add	a,#0xfa
      003776 F5 81            [12] 1831 	mov	sp,a
      003778 D0 00            [24] 1832 	pop	ar0
      00377A D0 01            [24] 1833 	pop	ar1
      00377C D0 02            [24] 1834 	pop	ar2
      00377E D0 05            [24] 1835 	pop	ar5
      003780 D0 06            [24] 1836 	pop	ar6
      003782 D0 07            [24] 1837 	pop	ar7
                                   1838 ;	D:\Codeblocks\lab3_v2\main.c:294: printf("\n\r Number of free spaces remaining in Buffer0 %d",((buffer0_size)-(user_alpha)));
      003784 AE 17            [24] 1839 	mov	r6,_main_sloc6_1_0
      003786 7F 00            [12] 1840 	mov	r7,#0x00
      003788 8E 04            [24] 1841 	mov	ar4,r6
      00378A 8F 05            [24] 1842 	mov	ar5,r7
      00378C E5 0D            [12] 1843 	mov	a,_main_sloc2_1_0
      00378E C3               [12] 1844 	clr	c
      00378F 9C               [12] 1845 	subb	a,r4
      003790 FC               [12] 1846 	mov	r4,a
      003791 E5 0E            [12] 1847 	mov	a,(_main_sloc2_1_0 + 1)
      003793 9D               [12] 1848 	subb	a,r5
      003794 FD               [12] 1849 	mov	r5,a
      003795 C0 07            [24] 1850 	push	ar7
      003797 C0 06            [24] 1851 	push	ar6
      003799 C0 05            [24] 1852 	push	ar5
      00379B C0 02            [24] 1853 	push	ar2
      00379D C0 01            [24] 1854 	push	ar1
      00379F C0 00            [24] 1855 	push	ar0
      0037A1 C0 04            [24] 1856 	push	ar4
      0037A3 C0 05            [24] 1857 	push	ar5
      0037A5 74 0B            [12] 1858 	mov	a,#___str_15
      0037A7 C0 E0            [24] 1859 	push	acc
      0037A9 74 4C            [12] 1860 	mov	a,#(___str_15 >> 8)
      0037AB C0 E0            [24] 1861 	push	acc
      0037AD 74 80            [12] 1862 	mov	a,#0x80
      0037AF C0 E0            [24] 1863 	push	acc
      0037B1 12 40 4C         [24] 1864 	lcall	_printf
      0037B4 E5 81            [12] 1865 	mov	a,sp
      0037B6 24 FB            [12] 1866 	add	a,#0xfb
      0037B8 F5 81            [12] 1867 	mov	sp,a
                                   1868 ;	D:\Codeblocks\lab3_v2\main.c:295: printf("\n\r Total allocated size of the buffer0 %d",buffer0_size);
      0037BA C0 0D            [24] 1869 	push	_main_sloc2_1_0
      0037BC C0 0E            [24] 1870 	push	(_main_sloc2_1_0 + 1)
      0037BE 74 3C            [12] 1871 	mov	a,#___str_16
      0037C0 C0 E0            [24] 1872 	push	acc
      0037C2 74 4C            [12] 1873 	mov	a,#(___str_16 >> 8)
      0037C4 C0 E0            [24] 1874 	push	acc
      0037C6 74 80            [12] 1875 	mov	a,#0x80
      0037C8 C0 E0            [24] 1876 	push	acc
      0037CA 12 40 4C         [24] 1877 	lcall	_printf
      0037CD E5 81            [12] 1878 	mov	a,sp
      0037CF 24 FB            [12] 1879 	add	a,#0xfb
      0037D1 F5 81            [12] 1880 	mov	sp,a
      0037D3 D0 00            [24] 1881 	pop	ar0
      0037D5 D0 01            [24] 1882 	pop	ar1
      0037D7 D0 02            [24] 1883 	pop	ar2
                                   1884 ;	D:\Codeblocks\lab3_v2\main.c:296: printf("\n\r Buffer1 Start Address %p",buff1_ptr);
      0037D9 C0 02            [24] 1885 	push	ar2
      0037DB C0 01            [24] 1886 	push	ar1
      0037DD C0 00            [24] 1887 	push	ar0
      0037DF C0 01            [24] 1888 	push	ar1
      0037E1 C0 00            [24] 1889 	push	ar0
      0037E3 C0 02            [24] 1890 	push	ar2
      0037E5 74 66            [12] 1891 	mov	a,#___str_17
      0037E7 C0 E0            [24] 1892 	push	acc
      0037E9 74 4C            [12] 1893 	mov	a,#(___str_17 >> 8)
      0037EB C0 E0            [24] 1894 	push	acc
      0037ED 74 80            [12] 1895 	mov	a,#0x80
      0037EF C0 E0            [24] 1896 	push	acc
      0037F1 12 40 4C         [24] 1897 	lcall	_printf
      0037F4 E5 81            [12] 1898 	mov	a,sp
      0037F6 24 FA            [12] 1899 	add	a,#0xfa
      0037F8 F5 81            [12] 1900 	mov	sp,a
      0037FA D0 00            [24] 1901 	pop	ar0
      0037FC D0 01            [24] 1902 	pop	ar1
      0037FE D0 02            [24] 1903 	pop	ar2
      003800 D0 05            [24] 1904 	pop	ar5
                                   1905 ;	D:\Codeblocks\lab3_v2\main.c:297: printf("\n\r Buffer1 End Address is %p",(buff1_ptr+(buffer0_size)));
      003802 E5 12            [12] 1906 	mov	a,_main_sloc4_1_0
      003804 29               [12] 1907 	add	a,r1
      003805 FB               [12] 1908 	mov	r3,a
      003806 E5 13            [12] 1909 	mov	a,(_main_sloc4_1_0 + 1)
      003808 38               [12] 1910 	addc	a,r0
      003809 FC               [12] 1911 	mov	r4,a
      00380A 8A 05            [24] 1912 	mov	ar5,r2
      00380C C0 05            [24] 1913 	push	ar5
      00380E C0 02            [24] 1914 	push	ar2
      003810 C0 01            [24] 1915 	push	ar1
      003812 C0 00            [24] 1916 	push	ar0
      003814 C0 03            [24] 1917 	push	ar3
      003816 C0 04            [24] 1918 	push	ar4
      003818 C0 05            [24] 1919 	push	ar5
      00381A 74 82            [12] 1920 	mov	a,#___str_18
      00381C C0 E0            [24] 1921 	push	acc
      00381E 74 4C            [12] 1922 	mov	a,#(___str_18 >> 8)
      003820 C0 E0            [24] 1923 	push	acc
      003822 74 80            [12] 1924 	mov	a,#0x80
      003824 C0 E0            [24] 1925 	push	acc
      003826 12 40 4C         [24] 1926 	lcall	_printf
      003829 E5 81            [12] 1927 	mov	a,sp
      00382B 24 FA            [12] 1928 	add	a,#0xfa
      00382D F5 81            [12] 1929 	mov	sp,a
                                   1930 ;	D:\Codeblocks\lab3_v2\main.c:298: printf("\n\r Number of free spaces remaining in Buffer0 %d",buffer0_size);
      00382F C0 0D            [24] 1931 	push	_main_sloc2_1_0
      003831 C0 0E            [24] 1932 	push	(_main_sloc2_1_0 + 1)
      003833 74 0B            [12] 1933 	mov	a,#___str_15
      003835 C0 E0            [24] 1934 	push	acc
      003837 74 4C            [12] 1935 	mov	a,#(___str_15 >> 8)
      003839 C0 E0            [24] 1936 	push	acc
      00383B 74 80            [12] 1937 	mov	a,#0x80
      00383D C0 E0            [24] 1938 	push	acc
      00383F 12 40 4C         [24] 1939 	lcall	_printf
      003842 E5 81            [12] 1940 	mov	a,sp
      003844 24 FB            [12] 1941 	add	a,#0xfb
      003846 F5 81            [12] 1942 	mov	sp,a
                                   1943 ;	D:\Codeblocks\lab3_v2\main.c:299: printf("\n\r Total allocated size of the buffer1 %d",buffer0_size);
      003848 C0 0D            [24] 1944 	push	_main_sloc2_1_0
      00384A C0 0E            [24] 1945 	push	(_main_sloc2_1_0 + 1)
      00384C 74 9F            [12] 1946 	mov	a,#___str_19
      00384E C0 E0            [24] 1947 	push	acc
      003850 74 4C            [12] 1948 	mov	a,#(___str_19 >> 8)
      003852 C0 E0            [24] 1949 	push	acc
      003854 74 80            [12] 1950 	mov	a,#0x80
      003856 C0 E0            [24] 1951 	push	acc
      003858 12 40 4C         [24] 1952 	lcall	_printf
      00385B E5 81            [12] 1953 	mov	a,sp
      00385D 24 FB            [12] 1954 	add	a,#0xfb
      00385F F5 81            [12] 1955 	mov	sp,a
      003861 D0 00            [24] 1956 	pop	ar0
      003863 D0 01            [24] 1957 	pop	ar1
      003865 D0 02            [24] 1958 	pop	ar2
      003867 D0 05            [24] 1959 	pop	ar5
      003869 D0 06            [24] 1960 	pop	ar6
      00386B D0 07            [24] 1961 	pop	ar7
                                   1962 ;	D:\Codeblocks\lab3_v2\main.c:301: printf("\n\r Number of storage characters in the buffer0 %d",user_alpha);
      00386D C0 07            [24] 1963 	push	ar7
      00386F C0 06            [24] 1964 	push	ar6
      003871 C0 05            [24] 1965 	push	ar5
      003873 C0 02            [24] 1966 	push	ar2
      003875 C0 01            [24] 1967 	push	ar1
      003877 C0 00            [24] 1968 	push	ar0
      003879 C0 06            [24] 1969 	push	ar6
      00387B C0 07            [24] 1970 	push	ar7
      00387D 74 C9            [12] 1971 	mov	a,#___str_20
      00387F C0 E0            [24] 1972 	push	acc
      003881 74 4C            [12] 1973 	mov	a,#(___str_20 >> 8)
      003883 C0 E0            [24] 1974 	push	acc
      003885 74 80            [12] 1975 	mov	a,#0x80
      003887 C0 E0            [24] 1976 	push	acc
      003889 12 40 4C         [24] 1977 	lcall	_printf
      00388C E5 81            [12] 1978 	mov	a,sp
      00388E 24 FB            [12] 1979 	add	a,#0xfb
      003890 F5 81            [12] 1980 	mov	sp,a
      003892 D0 00            [24] 1981 	pop	ar0
      003894 D0 01            [24] 1982 	pop	ar1
      003896 D0 02            [24] 1983 	pop	ar2
      003898 D0 05            [24] 1984 	pop	ar5
      00389A D0 06            [24] 1985 	pop	ar6
      00389C D0 07            [24] 1986 	pop	ar7
                                   1987 ;	D:\Codeblocks\lab3_v2\main.c:303: for(uint8_t i=2;i<=count;i++)
      00389E 85 18 20         [24] 1988 	mov	_main_sloc12_1_0,_main_sloc7_1_0
      0038A1 75 1E 02         [24] 1989 	mov	_main_sloc11_1_0,#0x02
                                   1990 ;	D:\Codeblocks\lab3_v2\main.c:357: return 0;
      0038A4 D0 07            [24] 1991 	pop	ar7
      0038A6 D0 06            [24] 1992 	pop	ar6
      0038A8 D0 05            [24] 1993 	pop	ar5
                                   1994 ;	D:\Codeblocks\lab3_v2\main.c:303: for(uint8_t i=2;i<=count;i++)
      0038AA                       1995 00159$:
      0038AA C3               [12] 1996 	clr	c
      0038AB E5 20            [12] 1997 	mov	a,_main_sloc12_1_0
      0038AD 95 1E            [12] 1998 	subb	a,_main_sloc11_1_0
      0038AF 50 03            [24] 1999 	jnc	00330$
      0038B1 02 39 62         [24] 2000 	ljmp	00124$
      0038B4                       2001 00330$:
                                   2002 ;	D:\Codeblocks\lab3_v2\main.c:305: printf("\n\r Buffer %d Start Address %p",i,buffptr_forplus[i]);
      0038B4 C0 01            [24] 2003 	push	ar1
      0038B6 C0 00            [24] 2004 	push	ar0
      0038B8 C0 02            [24] 2005 	push	ar2
      0038BA E5 1E            [12] 2006 	mov	a,_main_sloc11_1_0
      0038BC 75 F0 03         [24] 2007 	mov	b,#0x03
      0038BF A4               [48] 2008 	mul	ab
      0038C0 24 1F            [12] 2009 	add	a,#_main_buffptr_forplus_131072_75
      0038C2 F5 82            [12] 2010 	mov	dpl,a
      0038C4 74 14            [12] 2011 	mov	a,#(_main_buffptr_forplus_131072_75 >> 8)
      0038C6 35 F0            [12] 2012 	addc	a,b
      0038C8 F5 83            [12] 2013 	mov	dph,a
      0038CA E0               [24] 2014 	movx	a,@dptr
      0038CB FA               [12] 2015 	mov	r2,a
      0038CC A3               [24] 2016 	inc	dptr
      0038CD E0               [24] 2017 	movx	a,@dptr
      0038CE FB               [12] 2018 	mov	r3,a
      0038CF A3               [24] 2019 	inc	dptr
      0038D0 E0               [24] 2020 	movx	a,@dptr
      0038D1 FC               [12] 2021 	mov	r4,a
      0038D2 A8 1E            [24] 2022 	mov	r0,_main_sloc11_1_0
      0038D4 79 00            [12] 2023 	mov	r1,#0x00
      0038D6 C0 07            [24] 2024 	push	ar7
      0038D8 C0 06            [24] 2025 	push	ar6
      0038DA C0 05            [24] 2026 	push	ar5
      0038DC C0 02            [24] 2027 	push	ar2
      0038DE C0 01            [24] 2028 	push	ar1
      0038E0 C0 00            [24] 2029 	push	ar0
      0038E2 C0 02            [24] 2030 	push	ar2
      0038E4 C0 03            [24] 2031 	push	ar3
      0038E6 C0 04            [24] 2032 	push	ar4
      0038E8 C0 00            [24] 2033 	push	ar0
      0038EA C0 01            [24] 2034 	push	ar1
      0038EC 74 FB            [12] 2035 	mov	a,#___str_21
      0038EE C0 E0            [24] 2036 	push	acc
      0038F0 74 4C            [12] 2037 	mov	a,#(___str_21 >> 8)
      0038F2 C0 E0            [24] 2038 	push	acc
      0038F4 74 80            [12] 2039 	mov	a,#0x80
      0038F6 C0 E0            [24] 2040 	push	acc
      0038F8 12 40 4C         [24] 2041 	lcall	_printf
      0038FB E5 81            [12] 2042 	mov	a,sp
      0038FD 24 F8            [12] 2043 	add	a,#0xf8
      0038FF F5 81            [12] 2044 	mov	sp,a
      003901 D0 00            [24] 2045 	pop	ar0
      003903 D0 01            [24] 2046 	pop	ar1
      003905 D0 02            [24] 2047 	pop	ar2
      003907 D0 05            [24] 2048 	pop	ar5
      003909 D0 06            [24] 2049 	pop	ar6
      00390B D0 07            [24] 2050 	pop	ar7
                                   2051 ;	D:\Codeblocks\lab3_v2\main.c:306: printf("\n\r Number of free spaces remaining in Buffer%d\t\t %d",i, arr_forfree_space[i]);
      00390D E5 1E            [12] 2052 	mov	a,_main_sloc11_1_0
      00390F 75 F0 02         [24] 2053 	mov	b,#0x02
      003912 A4               [48] 2054 	mul	ab
      003913 24 C5            [12] 2055 	add	a,#_main_arr_forfree_space_131072_75
      003915 F5 82            [12] 2056 	mov	dpl,a
      003917 74 13            [12] 2057 	mov	a,#(_main_arr_forfree_space_131072_75 >> 8)
      003919 35 F0            [12] 2058 	addc	a,b
      00391B F5 83            [12] 2059 	mov	dph,a
      00391D E0               [24] 2060 	movx	a,@dptr
      00391E FB               [12] 2061 	mov	r3,a
      00391F A3               [24] 2062 	inc	dptr
      003920 E0               [24] 2063 	movx	a,@dptr
      003921 FC               [12] 2064 	mov	r4,a
      003922 C0 07            [24] 2065 	push	ar7
      003924 C0 06            [24] 2066 	push	ar6
      003926 C0 05            [24] 2067 	push	ar5
      003928 C0 02            [24] 2068 	push	ar2
      00392A C0 01            [24] 2069 	push	ar1
      00392C C0 00            [24] 2070 	push	ar0
      00392E C0 03            [24] 2071 	push	ar3
      003930 C0 04            [24] 2072 	push	ar4
      003932 C0 00            [24] 2073 	push	ar0
      003934 C0 01            [24] 2074 	push	ar1
      003936 74 19            [12] 2075 	mov	a,#___str_22
      003938 C0 E0            [24] 2076 	push	acc
      00393A 74 4D            [12] 2077 	mov	a,#(___str_22 >> 8)
      00393C C0 E0            [24] 2078 	push	acc
      00393E 74 80            [12] 2079 	mov	a,#0x80
      003940 C0 E0            [24] 2080 	push	acc
      003942 12 40 4C         [24] 2081 	lcall	_printf
      003945 E5 81            [12] 2082 	mov	a,sp
      003947 24 F9            [12] 2083 	add	a,#0xf9
      003949 F5 81            [12] 2084 	mov	sp,a
      00394B D0 00            [24] 2085 	pop	ar0
      00394D D0 01            [24] 2086 	pop	ar1
      00394F D0 02            [24] 2087 	pop	ar2
      003951 D0 05            [24] 2088 	pop	ar5
      003953 D0 06            [24] 2089 	pop	ar6
      003955 D0 07            [24] 2090 	pop	ar7
                                   2091 ;	D:\Codeblocks\lab3_v2\main.c:303: for(uint8_t i=2;i<=count;i++)
      003957 05 1E            [12] 2092 	inc	_main_sloc11_1_0
      003959 D0 02            [24] 2093 	pop	ar2
      00395B D0 00            [24] 2094 	pop	ar0
      00395D D0 01            [24] 2095 	pop	ar1
      00395F 02 38 AA         [24] 2096 	ljmp	00159$
      003962                       2097 00124$:
                                   2098 ;	D:\Codeblocks\lab3_v2\main.c:308: for(uint8_t i=0;i<=user_alpha;i++)
      003962 AC 17            [24] 2099 	mov	r4,_main_sloc6_1_0
      003964 7B 00            [12] 2100 	mov	r3,#0x00
      003966                       2101 00162$:
      003966 C3               [12] 2102 	clr	c
      003967 EC               [12] 2103 	mov	a,r4
      003968 9B               [12] 2104 	subb	a,r3
      003969 50 03            [24] 2105 	jnc	00331$
      00396B 02 32 CE         [24] 2106 	ljmp	00153$
      00396E                       2107 00331$:
                                   2108 ;	D:\Codeblocks\lab3_v2\main.c:310: printf("\n\r All the characters of an array are: %c", arr_to_store[i]);
      00396E C0 01            [24] 2109 	push	ar1
      003970 C0 00            [24] 2110 	push	ar0
      003972 C0 02            [24] 2111 	push	ar2
      003974 EB               [12] 2112 	mov	a,r3
      003975 24 01            [12] 2113 	add	a,#_main_arr_to_store_131072_75
      003977 F5 82            [12] 2114 	mov	dpl,a
      003979 E4               [12] 2115 	clr	a
      00397A 34 14            [12] 2116 	addc	a,#(_main_arr_to_store_131072_75 >> 8)
      00397C F5 83            [12] 2117 	mov	dph,a
      00397E E0               [24] 2118 	movx	a,@dptr
      00397F F9               [12] 2119 	mov	r1,a
      003980 7A 00            [12] 2120 	mov	r2,#0x00
      003982 C0 07            [24] 2121 	push	ar7
      003984 C0 06            [24] 2122 	push	ar6
      003986 C0 05            [24] 2123 	push	ar5
      003988 C0 04            [24] 2124 	push	ar4
      00398A C0 03            [24] 2125 	push	ar3
      00398C C0 02            [24] 2126 	push	ar2
      00398E C0 01            [24] 2127 	push	ar1
      003990 C0 00            [24] 2128 	push	ar0
      003992 C0 01            [24] 2129 	push	ar1
      003994 C0 02            [24] 2130 	push	ar2
      003996 74 4D            [12] 2131 	mov	a,#___str_23
      003998 C0 E0            [24] 2132 	push	acc
      00399A 74 4D            [12] 2133 	mov	a,#(___str_23 >> 8)
      00399C C0 E0            [24] 2134 	push	acc
      00399E 74 80            [12] 2135 	mov	a,#0x80
      0039A0 C0 E0            [24] 2136 	push	acc
      0039A2 12 40 4C         [24] 2137 	lcall	_printf
      0039A5 E5 81            [12] 2138 	mov	a,sp
      0039A7 24 FB            [12] 2139 	add	a,#0xfb
      0039A9 F5 81            [12] 2140 	mov	sp,a
      0039AB D0 00            [24] 2141 	pop	ar0
      0039AD D0 01            [24] 2142 	pop	ar1
      0039AF D0 02            [24] 2143 	pop	ar2
      0039B1 D0 03            [24] 2144 	pop	ar3
      0039B3 D0 04            [24] 2145 	pop	ar4
      0039B5 D0 05            [24] 2146 	pop	ar5
      0039B7 D0 06            [24] 2147 	pop	ar6
      0039B9 D0 07            [24] 2148 	pop	ar7
                                   2149 ;	D:\Codeblocks\lab3_v2\main.c:308: for(uint8_t i=0;i<=user_alpha;i++)
      0039BB 0B               [12] 2150 	inc	r3
      0039BC D0 02            [24] 2151 	pop	ar2
      0039BE D0 00            [24] 2152 	pop	ar0
      0039C0 D0 01            [24] 2153 	pop	ar1
      0039C2 80 A2            [24] 2154 	sjmp	00162$
      0039C4                       2155 00127$:
                                   2156 ;	D:\Codeblocks\lab3_v2\main.c:315: free(buff0_base);
      0039C4 C0 01            [24] 2157 	push	ar1
      0039C6 C0 00            [24] 2158 	push	ar0
      0039C8 C0 02            [24] 2159 	push	ar2
      0039CA AA 14            [24] 2160 	mov	r2,_main_sloc5_1_0
      0039CC AB 15            [24] 2161 	mov	r3,(_main_sloc5_1_0 + 1)
      0039CE AC 16            [24] 2162 	mov	r4,(_main_sloc5_1_0 + 2)
      0039D0 8A 82            [24] 2163 	mov	dpl,r2
      0039D2 8B 83            [24] 2164 	mov	dph,r3
      0039D4 8C F0            [24] 2165 	mov	b,r4
      0039D6 C0 07            [24] 2166 	push	ar7
      0039D8 C0 06            [24] 2167 	push	ar6
      0039DA C0 05            [24] 2168 	push	ar5
      0039DC C0 02            [24] 2169 	push	ar2
      0039DE C0 01            [24] 2170 	push	ar1
      0039E0 C0 00            [24] 2171 	push	ar0
      0039E2 12 3B A7         [24] 2172 	lcall	_free
      0039E5 D0 00            [24] 2173 	pop	ar0
      0039E7 D0 01            [24] 2174 	pop	ar1
      0039E9 D0 02            [24] 2175 	pop	ar2
      0039EB D0 05            [24] 2176 	pop	ar5
      0039ED D0 06            [24] 2177 	pop	ar6
      0039EF D0 07            [24] 2178 	pop	ar7
      0039F1 D0 02            [24] 2179 	pop	ar2
      0039F3 D0 00            [24] 2180 	pop	ar0
      0039F5 D0 01            [24] 2181 	pop	ar1
      0039F7 02 32 CE         [24] 2182 	ljmp	00153$
      0039FA                       2183 00140$:
                                   2184 ;	D:\Codeblocks\lab3_v2\main.c:324: else if(ip_user=='=')
      0039FA 74 3D            [12] 2185 	mov	a,#0x3d
      0039FC B5 1C 02         [24] 2186 	cjne	a,_main_sloc10_1_0,00332$
      0039FF 80 03            [24] 2187 	sjmp	00333$
      003A01                       2188 00332$:
      003A01 02 3B 3D         [24] 2189 	ljmp	00137$
      003A04                       2190 00333$:
                                   2191 ;	D:\Codeblocks\lab3_v2\main.c:327: printf("\n\r %p\t",save_start_to_buff0);
      003A04 C0 07            [24] 2192 	push	ar7
      003A06 C0 06            [24] 2193 	push	ar6
      003A08 C0 05            [24] 2194 	push	ar5
      003A0A C0 02            [24] 2195 	push	ar2
      003A0C C0 01            [24] 2196 	push	ar1
      003A0E C0 00            [24] 2197 	push	ar0
      003A10 90 13 C0         [24] 2198 	mov	dptr,#_main_save_start_to_buff0_131072_75
      003A13 E0               [24] 2199 	movx	a,@dptr
      003A14 C0 E0            [24] 2200 	push	acc
      003A16 A3               [24] 2201 	inc	dptr
      003A17 E0               [24] 2202 	movx	a,@dptr
      003A18 C0 E0            [24] 2203 	push	acc
      003A1A A3               [24] 2204 	inc	dptr
      003A1B E0               [24] 2205 	movx	a,@dptr
      003A1C C0 E0            [24] 2206 	push	acc
      003A1E 74 77            [12] 2207 	mov	a,#___str_24
      003A20 C0 E0            [24] 2208 	push	acc
      003A22 74 4D            [12] 2209 	mov	a,#(___str_24 >> 8)
      003A24 C0 E0            [24] 2210 	push	acc
      003A26 74 80            [12] 2211 	mov	a,#0x80
      003A28 C0 E0            [24] 2212 	push	acc
      003A2A 12 40 4C         [24] 2213 	lcall	_printf
      003A2D E5 81            [12] 2214 	mov	a,sp
      003A2F 24 FA            [12] 2215 	add	a,#0xfa
      003A31 F5 81            [12] 2216 	mov	sp,a
      003A33 D0 00            [24] 2217 	pop	ar0
      003A35 D0 01            [24] 2218 	pop	ar1
      003A37 D0 02            [24] 2219 	pop	ar2
      003A39 D0 05            [24] 2220 	pop	ar5
      003A3B D0 06            [24] 2221 	pop	ar6
      003A3D D0 07            [24] 2222 	pop	ar7
                                   2223 ;	D:\Codeblocks\lab3_v2\main.c:330: for(uint8_t i=0;i<=user_alpha;i++)
      003A3F 90 13 C0         [24] 2224 	mov	dptr,#_main_save_start_to_buff0_131072_75
      003A42 E0               [24] 2225 	movx	a,@dptr
      003A43 F5 24            [12] 2226 	mov	_main_sloc14_1_0,a
      003A45 A3               [24] 2227 	inc	dptr
      003A46 E0               [24] 2228 	movx	a,@dptr
      003A47 F5 25            [12] 2229 	mov	(_main_sloc14_1_0 + 1),a
      003A49 A3               [24] 2230 	inc	dptr
      003A4A E0               [24] 2231 	movx	a,@dptr
      003A4B F5 26            [12] 2232 	mov	(_main_sloc14_1_0 + 2),a
      003A4D 85 24 27         [24] 2233 	mov	_main_sloc15_1_0,_main_sloc14_1_0
      003A50 85 25 28         [24] 2234 	mov	(_main_sloc15_1_0 + 1),(_main_sloc14_1_0 + 1)
      003A53 85 26 29         [24] 2235 	mov	(_main_sloc15_1_0 + 2),(_main_sloc14_1_0 + 2)
      003A56 AC 17            [24] 2236 	mov	r4,_main_sloc6_1_0
      003A58 7B 00            [12] 2237 	mov	r3,#0x00
      003A5A                       2238 00165$:
      003A5A C3               [12] 2239 	clr	c
      003A5B EC               [12] 2240 	mov	a,r4
      003A5C 9B               [12] 2241 	subb	a,r3
      003A5D 50 03            [24] 2242 	jnc	00334$
      003A5F 02 32 CE         [24] 2243 	ljmp	00153$
      003A62                       2244 00334$:
                                   2245 ;	D:\Codeblocks\lab3_v2\main.c:333: if(((i%16) == 0) && i != 0)
      003A62 C0 01            [24] 2246 	push	ar1
      003A64 C0 00            [24] 2247 	push	ar0
      003A66 C0 02            [24] 2248 	push	ar2
      003A68 8B 01            [24] 2249 	mov	ar1,r3
      003A6A E9               [12] 2250 	mov	a,r1
      003A6B 54 0F            [12] 2251 	anl	a,#0x0f
      003A6D 60 08            [24] 2252 	jz	00336$
      003A6F D0 02            [24] 2253 	pop	ar2
      003A71 D0 00            [24] 2254 	pop	ar0
      003A73 D0 01            [24] 2255 	pop	ar1
      003A75 80 5F            [24] 2256 	sjmp	00130$
      003A77                       2257 00336$:
      003A77 D0 02            [24] 2258 	pop	ar2
      003A79 D0 00            [24] 2259 	pop	ar0
      003A7B D0 01            [24] 2260 	pop	ar1
      003A7D EB               [12] 2261 	mov	a,r3
      003A7E 60 56            [24] 2262 	jz	00130$
                                   2263 ;	D:\Codeblocks\lab3_v2\main.c:335: printf("\n\r%p\t",((save_start_to_buff0)+i));
      003A80 C0 01            [24] 2264 	push	ar1
      003A82 C0 00            [24] 2265 	push	ar0
      003A84 C0 02            [24] 2266 	push	ar2
      003A86 EB               [12] 2267 	mov	a,r3
      003A87 75 F0 02         [24] 2268 	mov	b,#0x02
      003A8A A4               [48] 2269 	mul	ab
      003A8B 25 24            [12] 2270 	add	a,_main_sloc14_1_0
      003A8D F8               [12] 2271 	mov	r0,a
      003A8E E5 25            [12] 2272 	mov	a,(_main_sloc14_1_0 + 1)
      003A90 35 F0            [12] 2273 	addc	a,b
      003A92 F9               [12] 2274 	mov	r1,a
      003A93 AA 26            [24] 2275 	mov	r2,(_main_sloc14_1_0 + 2)
      003A95 C0 07            [24] 2276 	push	ar7
      003A97 C0 06            [24] 2277 	push	ar6
      003A99 C0 05            [24] 2278 	push	ar5
      003A9B C0 04            [24] 2279 	push	ar4
      003A9D C0 03            [24] 2280 	push	ar3
      003A9F C0 02            [24] 2281 	push	ar2
      003AA1 C0 01            [24] 2282 	push	ar1
      003AA3 C0 00            [24] 2283 	push	ar0
      003AA5 C0 00            [24] 2284 	push	ar0
      003AA7 C0 01            [24] 2285 	push	ar1
      003AA9 C0 02            [24] 2286 	push	ar2
      003AAB 74 7E            [12] 2287 	mov	a,#___str_25
      003AAD C0 E0            [24] 2288 	push	acc
      003AAF 74 4D            [12] 2289 	mov	a,#(___str_25 >> 8)
      003AB1 C0 E0            [24] 2290 	push	acc
      003AB3 74 80            [12] 2291 	mov	a,#0x80
      003AB5 C0 E0            [24] 2292 	push	acc
      003AB7 12 40 4C         [24] 2293 	lcall	_printf
      003ABA E5 81            [12] 2294 	mov	a,sp
      003ABC 24 FA            [12] 2295 	add	a,#0xfa
      003ABE F5 81            [12] 2296 	mov	sp,a
      003AC0 D0 00            [24] 2297 	pop	ar0
      003AC2 D0 01            [24] 2298 	pop	ar1
      003AC4 D0 02            [24] 2299 	pop	ar2
      003AC6 D0 03            [24] 2300 	pop	ar3
      003AC8 D0 04            [24] 2301 	pop	ar4
      003ACA D0 05            [24] 2302 	pop	ar5
      003ACC D0 06            [24] 2303 	pop	ar6
      003ACE D0 07            [24] 2304 	pop	ar7
                                   2305 ;	D:\Codeblocks\lab3_v2\main.c:357: return 0;
      003AD0 D0 02            [24] 2306 	pop	ar2
      003AD2 D0 00            [24] 2307 	pop	ar0
      003AD4 D0 01            [24] 2308 	pop	ar1
                                   2309 ;	D:\Codeblocks\lab3_v2\main.c:335: printf("\n\r%p\t",((save_start_to_buff0)+i));
      003AD6                       2310 00130$:
                                   2311 ;	D:\Codeblocks\lab3_v2\main.c:338: printf("%X ",*(save_start_to_buff0+i));
      003AD6 C0 01            [24] 2312 	push	ar1
      003AD8 C0 00            [24] 2313 	push	ar0
      003ADA C0 02            [24] 2314 	push	ar2
      003ADC EB               [12] 2315 	mov	a,r3
      003ADD 75 F0 02         [24] 2316 	mov	b,#0x02
      003AE0 A4               [48] 2317 	mul	ab
      003AE1 25 27            [12] 2318 	add	a,_main_sloc15_1_0
      003AE3 F8               [12] 2319 	mov	r0,a
      003AE4 E5 28            [12] 2320 	mov	a,(_main_sloc15_1_0 + 1)
      003AE6 35 F0            [12] 2321 	addc	a,b
      003AE8 F9               [12] 2322 	mov	r1,a
      003AE9 AA 29            [24] 2323 	mov	r2,(_main_sloc15_1_0 + 2)
      003AEB 88 82            [24] 2324 	mov	dpl,r0
      003AED 89 83            [24] 2325 	mov	dph,r1
      003AEF 8A F0            [24] 2326 	mov	b,r2
      003AF1 12 4A 6E         [24] 2327 	lcall	__gptrget
      003AF4 F8               [12] 2328 	mov	r0,a
      003AF5 A3               [24] 2329 	inc	dptr
      003AF6 12 4A 6E         [24] 2330 	lcall	__gptrget
      003AF9 F9               [12] 2331 	mov	r1,a
      003AFA C0 07            [24] 2332 	push	ar7
      003AFC C0 06            [24] 2333 	push	ar6
      003AFE C0 05            [24] 2334 	push	ar5
      003B00 C0 04            [24] 2335 	push	ar4
      003B02 C0 03            [24] 2336 	push	ar3
      003B04 C0 02            [24] 2337 	push	ar2
      003B06 C0 01            [24] 2338 	push	ar1
      003B08 C0 00            [24] 2339 	push	ar0
      003B0A C0 00            [24] 2340 	push	ar0
      003B0C C0 01            [24] 2341 	push	ar1
      003B0E 74 84            [12] 2342 	mov	a,#___str_26
      003B10 C0 E0            [24] 2343 	push	acc
      003B12 74 4D            [12] 2344 	mov	a,#(___str_26 >> 8)
      003B14 C0 E0            [24] 2345 	push	acc
      003B16 74 80            [12] 2346 	mov	a,#0x80
      003B18 C0 E0            [24] 2347 	push	acc
      003B1A 12 40 4C         [24] 2348 	lcall	_printf
      003B1D E5 81            [12] 2349 	mov	a,sp
      003B1F 24 FB            [12] 2350 	add	a,#0xfb
      003B21 F5 81            [12] 2351 	mov	sp,a
      003B23 D0 00            [24] 2352 	pop	ar0
      003B25 D0 01            [24] 2353 	pop	ar1
      003B27 D0 02            [24] 2354 	pop	ar2
      003B29 D0 03            [24] 2355 	pop	ar3
      003B2B D0 04            [24] 2356 	pop	ar4
      003B2D D0 05            [24] 2357 	pop	ar5
      003B2F D0 06            [24] 2358 	pop	ar6
      003B31 D0 07            [24] 2359 	pop	ar7
                                   2360 ;	D:\Codeblocks\lab3_v2\main.c:330: for(uint8_t i=0;i<=user_alpha;i++)
      003B33 0B               [12] 2361 	inc	r3
      003B34 D0 02            [24] 2362 	pop	ar2
      003B36 D0 00            [24] 2363 	pop	ar0
      003B38 D0 01            [24] 2364 	pop	ar1
      003B3A 02 3A 5A         [24] 2365 	ljmp	00165$
      003B3D                       2366 00137$:
                                   2367 ;	D:\Codeblocks\lab3_v2\main.c:344: else if(ip_user == '@')
      003B3D 74 40            [12] 2368 	mov	a,#0x40
      003B3F B5 1C 02         [24] 2369 	cjne	a,_main_sloc10_1_0,00338$
      003B42 80 03            [24] 2370 	sjmp	00339$
      003B44                       2371 00338$:
      003B44 02 32 CE         [24] 2372 	ljmp	00153$
      003B47                       2373 00339$:
                                   2374 ;	D:\Codeblocks\lab3_v2\main.c:346: free(buff0_base);
      003B47 90 13 BD         [24] 2375 	mov	dptr,#_main_buff0_base_131072_75
      003B4A E0               [24] 2376 	movx	a,@dptr
      003B4B FD               [12] 2377 	mov	r5,a
      003B4C A3               [24] 2378 	inc	dptr
      003B4D E0               [24] 2379 	movx	a,@dptr
      003B4E FE               [12] 2380 	mov	r6,a
      003B4F A3               [24] 2381 	inc	dptr
      003B50 E0               [24] 2382 	movx	a,@dptr
      003B51 FF               [12] 2383 	mov	r7,a
      003B52 8D 82            [24] 2384 	mov	dpl,r5
      003B54 8E 83            [24] 2385 	mov	dph,r6
      003B56 8F F0            [24] 2386 	mov	b,r7
      003B58 C0 02            [24] 2387 	push	ar2
      003B5A C0 01            [24] 2388 	push	ar1
      003B5C C0 00            [24] 2389 	push	ar0
      003B5E 12 3B A7         [24] 2390 	lcall	_free
      003B61 D0 00            [24] 2391 	pop	ar0
      003B63 D0 01            [24] 2392 	pop	ar1
      003B65 D0 02            [24] 2393 	pop	ar2
                                   2394 ;	D:\Codeblocks\lab3_v2\main.c:347: free(buff1_ptr);
      003B67 89 82            [24] 2395 	mov	dpl,r1
      003B69 88 83            [24] 2396 	mov	dph,r0
      003B6B 8A F0            [24] 2397 	mov	b,r2
      003B6D 12 3B A7         [24] 2398 	lcall	_free
                                   2399 ;	D:\Codeblocks\lab3_v2\main.c:348: for(uint8_t i=0;i<count;i++)
      003B70 AF 18            [24] 2400 	mov	r7,_main_sloc7_1_0
      003B72 7E 00            [12] 2401 	mov	r6,#0x00
      003B74                       2402 00168$:
      003B74 C3               [12] 2403 	clr	c
      003B75 EE               [12] 2404 	mov	a,r6
      003B76 9F               [12] 2405 	subb	a,r7
      003B77 40 03            [24] 2406 	jc	00340$
      003B79 02 31 1A         [24] 2407 	ljmp	00156$
      003B7C                       2408 00340$:
                                   2409 ;	D:\Codeblocks\lab3_v2\main.c:350: free(buffptr_forplus[count]);
      003B7C EF               [12] 2410 	mov	a,r7
      003B7D 75 F0 03         [24] 2411 	mov	b,#0x03
      003B80 A4               [48] 2412 	mul	ab
      003B81 24 1F            [12] 2413 	add	a,#_main_buffptr_forplus_131072_75
      003B83 F5 82            [12] 2414 	mov	dpl,a
      003B85 74 14            [12] 2415 	mov	a,#(_main_buffptr_forplus_131072_75 >> 8)
      003B87 35 F0            [12] 2416 	addc	a,b
      003B89 F5 83            [12] 2417 	mov	dph,a
      003B8B E0               [24] 2418 	movx	a,@dptr
      003B8C FB               [12] 2419 	mov	r3,a
      003B8D A3               [24] 2420 	inc	dptr
      003B8E E0               [24] 2421 	movx	a,@dptr
      003B8F FC               [12] 2422 	mov	r4,a
      003B90 A3               [24] 2423 	inc	dptr
      003B91 E0               [24] 2424 	movx	a,@dptr
      003B92 FD               [12] 2425 	mov	r5,a
      003B93 8B 82            [24] 2426 	mov	dpl,r3
      003B95 8C 83            [24] 2427 	mov	dph,r4
      003B97 8D F0            [24] 2428 	mov	b,r5
      003B99 C0 07            [24] 2429 	push	ar7
      003B9B C0 06            [24] 2430 	push	ar6
      003B9D 12 3B A7         [24] 2431 	lcall	_free
      003BA0 D0 06            [24] 2432 	pop	ar6
      003BA2 D0 07            [24] 2433 	pop	ar7
                                   2434 ;	D:\Codeblocks\lab3_v2\main.c:348: for(uint8_t i=0;i<count;i++)
      003BA4 0E               [12] 2435 	inc	r6
                                   2436 ;	D:\Codeblocks\lab3_v2\main.c:357: return 0;
                                   2437 ;	D:\Codeblocks\lab3_v2\main.c:359: }
      003BA5 80 CD            [24] 2438 	sjmp	00168$
                                   2439 	.area CSEG    (CODE)
                                   2440 	.area CONST   (CODE)
      004A8A                       2441 ___sdcc_heap_size:
      004A8A A0 0F                 2442 	.byte #0xa0, #0x0f	; 4000
                                   2443 	.area CONST   (CODE)
      004A8C                       2444 ___str_0:
      004A8C 45 6E 74 65 72 20 42  2445 	.ascii "Enter BUFFER size"
             55 46 46 45 52 20 73
             69 7A 65
      004A9D 0A                    2446 	.db 0x0a
      004A9E 00                    2447 	.db 0x00
                                   2448 	.area CSEG    (CODE)
                                   2449 	.area CONST   (CODE)
      004A9F                       2450 ___str_1:
      004A9F 54 68 65 20 42 55 46  2451 	.ascii "The BUFFER0 size entered by the user is %d"
             46 45 52 30 20 73 69
             7A 65 20 65 6E 74 65
             72 65 64 20 62 79 20
             74 68 65 20 75 73 65
             72 20 69 73 20 25 64
      004AC9 0A                    2452 	.db 0x0a
      004ACA 00                    2453 	.db 0x00
                                   2454 	.area CSEG    (CODE)
                                   2455 	.area CONST   (CODE)
      004ACB                       2456 ___str_2:
      004ACB 4D 61 6C 6C 6F 63 20  2457 	.ascii "Malloc Failed"
             46 61 69 6C 65 64
      004AD8 00                    2458 	.db 0x00
                                   2459 	.area CSEG    (CODE)
                                   2460 	.area CONST   (CODE)
      004AD9                       2461 ___str_3:
      004AD9 45 6E 74 65 72 20 76  2462 	.ascii "Enter value smaller than 1985bytes"
             61 6C 75 65 20 73 6D
             61 6C 6C 65 72 20 74
             68 61 6E 20 31 39 38
             35 62 79 74 65 73
      004AFB 00                    2463 	.db 0x00
                                   2464 	.area CSEG    (CODE)
                                   2465 	.area CONST   (CODE)
      004AFC                       2466 ___str_4:
      004AFC 0A                    2467 	.db 0x0a
      004AFD 0D                    2468 	.db 0x0d
      004AFE 45 6E 74 65 72 20 63  2469 	.ascii "Enter character:"
             68 61 72 61 63 74 65
             72 3A
      004B0E 00                    2470 	.db 0x00
                                   2471 	.area CSEG    (CODE)
                                   2472 	.area CONST   (CODE)
      004B0F                       2473 ___str_5:
      004B0F 0A                    2474 	.db 0x0a
      004B10 0D                    2475 	.db 0x0d
      004B11 20 41 64 64 72 65 73  2476 	.ascii " Address:%p"
             73 3A 25 70
      004B1C 09                    2477 	.db 0x09
      004B1D 09                    2478 	.db 0x09
      004B1E 09                    2479 	.db 0x09
      004B1F 20 7C                 2480 	.ascii " |"
      004B21 09                    2481 	.db 0x09
      004B22 09                    2482 	.db 0x09
      004B23 09                    2483 	.db 0x09
      004B24 20 25 63              2484 	.ascii " %c"
      004B27 00                    2485 	.db 0x00
                                   2486 	.area CSEG    (CODE)
                                   2487 	.area CONST   (CODE)
      004B28                       2488 ___str_6:
      004B28 45 78 74 72 61 20 63  2489 	.ascii "Extra characters on screen %c"
             68 61 72 61 63 74 65
             72 73 20 6F 6E 20 73
             63 72 65 65 6E 20 25
             63
      004B45 00                    2490 	.db 0x00
                                   2491 	.area CSEG    (CODE)
                                   2492 	.area CONST   (CODE)
      004B46                       2493 ___str_7:
      004B46 0A                    2494 	.db 0x0a
      004B47 0D                    2495 	.db 0x0d
      004B48 45 6E 74 65 72 20 6E  2496 	.ascii "Enter new buffer size between 30 to 300 bytes"
             65 77 20 62 75 66 66
             65 72 20 73 69 7A 65
             20 62 65 74 77 65 65
             6E 20 33 30 20 74 6F
             20 33 30 30 20 62 79
             74 65 73
      004B75 00                    2497 	.db 0x00
                                   2498 	.area CSEG    (CODE)
                                   2499 	.area CONST   (CODE)
      004B76                       2500 ___str_8:
      004B76 0A                    2501 	.db 0x0a
      004B77 0D                    2502 	.db 0x0d
      004B78 25 70 20              2503 	.ascii "%p "
      004B7B 0A                    2504 	.db 0x0a
      004B7C 00                    2505 	.db 0x00
                                   2506 	.area CSEG    (CODE)
                                   2507 	.area CONST   (CODE)
      004B7D                       2508 ___str_9:
      004B7D 0A                    2509 	.db 0x0a
      004B7E 0D                    2510 	.db 0x0d
      004B7F 45 6E 74 65 72 20 76  2511 	.ascii "Enter valid buffer number"
             61 6C 69 64 20 62 75
             66 66 65 72 20 6E 75
             6D 62 65 72
      004B98 00                    2512 	.db 0x00
                                   2513 	.area CSEG    (CODE)
                                   2514 	.area CONST   (CODE)
      004B99                       2515 ___str_10:
      004B99 0A                    2516 	.db 0x0a
      004B9A 0D                    2517 	.db 0x0d
      004B9B 76 61 6C 69 64 20 6E  2518 	.ascii "valid number"
             75 6D 62 65 72
      004BA7 00                    2519 	.db 0x00
                                   2520 	.area CSEG    (CODE)
                                   2521 	.area CONST   (CODE)
      004BA8                       2522 ___str_11:
      004BA8 0A                    2523 	.db 0x0a
      004BA9 0D                    2524 	.db 0x0d
      004BAA 49 6E 76 61 6C 69 64  2525 	.ascii "Invalid number"
             20 6E 75 6D 62 65 72
      004BB8 00                    2526 	.db 0x00
                                   2527 	.area CSEG    (CODE)
                                   2528 	.area CONST   (CODE)
      004BB9                       2529 ___str_12:
      004BB9 0A                    2530 	.db 0x0a
      004BBA 0D                    2531 	.db 0x0d
      004BBB 54 68 65 20 74 6F 74  2532 	.ascii "The total count is: %d"
             61 6C 20 63 6F 75 6E
             74 20 69 73 3A 20 25
             64
      004BD1 00                    2533 	.db 0x00
                                   2534 	.area CSEG    (CODE)
                                   2535 	.area CONST   (CODE)
      004BD2                       2536 ___str_13:
      004BD2 0A                    2537 	.db 0x0a
      004BD3 0D                    2538 	.db 0x0d
      004BD4 20 42 75 66 66 65 72  2539 	.ascii " Buffer0 Start Address %p"
             30 20 53 74 61 72 74
             20 41 64 64 72 65 73
             73 20 25 70
      004BED 00                    2540 	.db 0x00
                                   2541 	.area CSEG    (CODE)
                                   2542 	.area CONST   (CODE)
      004BEE                       2543 ___str_14:
      004BEE 0A                    2544 	.db 0x0a
      004BEF 0D                    2545 	.db 0x0d
      004BF0 20 42 75 66 66 65 72  2546 	.ascii " Buffer0 End Address is %p"
             30 20 45 6E 64 20 41
             64 64 72 65 73 73 20
             69 73 20 25 70
      004C0A 00                    2547 	.db 0x00
                                   2548 	.area CSEG    (CODE)
                                   2549 	.area CONST   (CODE)
      004C0B                       2550 ___str_15:
      004C0B 0A                    2551 	.db 0x0a
      004C0C 0D                    2552 	.db 0x0d
      004C0D 20 4E 75 6D 62 65 72  2553 	.ascii " Number of free spaces remaining in Buffer0 %d"
             20 6F 66 20 66 72 65
             65 20 73 70 61 63 65
             73 20 72 65 6D 61 69
             6E 69 6E 67 20 69 6E
             20 42 75 66 66 65 72
             30 20 25 64
      004C3B 00                    2554 	.db 0x00
                                   2555 	.area CSEG    (CODE)
                                   2556 	.area CONST   (CODE)
      004C3C                       2557 ___str_16:
      004C3C 0A                    2558 	.db 0x0a
      004C3D 0D                    2559 	.db 0x0d
      004C3E 20 54 6F 74 61 6C 20  2560 	.ascii " Total allocated size of the buffer0 %d"
             61 6C 6C 6F 63 61 74
             65 64 20 73 69 7A 65
             20 6F 66 20 74 68 65
             20 62 75 66 66 65 72
             30 20 25 64
      004C65 00                    2561 	.db 0x00
                                   2562 	.area CSEG    (CODE)
                                   2563 	.area CONST   (CODE)
      004C66                       2564 ___str_17:
      004C66 0A                    2565 	.db 0x0a
      004C67 0D                    2566 	.db 0x0d
      004C68 20 42 75 66 66 65 72  2567 	.ascii " Buffer1 Start Address %p"
             31 20 53 74 61 72 74
             20 41 64 64 72 65 73
             73 20 25 70
      004C81 00                    2568 	.db 0x00
                                   2569 	.area CSEG    (CODE)
                                   2570 	.area CONST   (CODE)
      004C82                       2571 ___str_18:
      004C82 0A                    2572 	.db 0x0a
      004C83 0D                    2573 	.db 0x0d
      004C84 20 42 75 66 66 65 72  2574 	.ascii " Buffer1 End Address is %p"
             31 20 45 6E 64 20 41
             64 64 72 65 73 73 20
             69 73 20 25 70
      004C9E 00                    2575 	.db 0x00
                                   2576 	.area CSEG    (CODE)
                                   2577 	.area CONST   (CODE)
      004C9F                       2578 ___str_19:
      004C9F 0A                    2579 	.db 0x0a
      004CA0 0D                    2580 	.db 0x0d
      004CA1 20 54 6F 74 61 6C 20  2581 	.ascii " Total allocated size of the buffer1 %d"
             61 6C 6C 6F 63 61 74
             65 64 20 73 69 7A 65
             20 6F 66 20 74 68 65
             20 62 75 66 66 65 72
             31 20 25 64
      004CC8 00                    2582 	.db 0x00
                                   2583 	.area CSEG    (CODE)
                                   2584 	.area CONST   (CODE)
      004CC9                       2585 ___str_20:
      004CC9 0A                    2586 	.db 0x0a
      004CCA 0D                    2587 	.db 0x0d
      004CCB 20 4E 75 6D 62 65 72  2588 	.ascii " Number of storage characters in the buffer0 %d"
             20 6F 66 20 73 74 6F
             72 61 67 65 20 63 68
             61 72 61 63 74 65 72
             73 20 69 6E 20 74 68
             65 20 62 75 66 66 65
             72 30 20 25 64
      004CFA 00                    2589 	.db 0x00
                                   2590 	.area CSEG    (CODE)
                                   2591 	.area CONST   (CODE)
      004CFB                       2592 ___str_21:
      004CFB 0A                    2593 	.db 0x0a
      004CFC 0D                    2594 	.db 0x0d
      004CFD 20 42 75 66 66 65 72  2595 	.ascii " Buffer %d Start Address %p"
             20 25 64 20 53 74 61
             72 74 20 41 64 64 72
             65 73 73 20 25 70
      004D18 00                    2596 	.db 0x00
                                   2597 	.area CSEG    (CODE)
                                   2598 	.area CONST   (CODE)
      004D19                       2599 ___str_22:
      004D19 0A                    2600 	.db 0x0a
      004D1A 0D                    2601 	.db 0x0d
      004D1B 20 4E 75 6D 62 65 72  2602 	.ascii " Number of free spaces remaining in Buffer%d"
             20 6F 66 20 66 72 65
             65 20 73 70 61 63 65
             73 20 72 65 6D 61 69
             6E 69 6E 67 20 69 6E
             20 42 75 66 66 65 72
             25 64
      004D47 09                    2603 	.db 0x09
      004D48 09                    2604 	.db 0x09
      004D49 20 25 64              2605 	.ascii " %d"
      004D4C 00                    2606 	.db 0x00
                                   2607 	.area CSEG    (CODE)
                                   2608 	.area CONST   (CODE)
      004D4D                       2609 ___str_23:
      004D4D 0A                    2610 	.db 0x0a
      004D4E 0D                    2611 	.db 0x0d
      004D4F 20 41 6C 6C 20 74 68  2612 	.ascii " All the characters of an array are: %c"
             65 20 63 68 61 72 61
             63 74 65 72 73 20 6F
             66 20 61 6E 20 61 72
             72 61 79 20 61 72 65
             3A 20 25 63
      004D76 00                    2613 	.db 0x00
                                   2614 	.area CSEG    (CODE)
                                   2615 	.area CONST   (CODE)
      004D77                       2616 ___str_24:
      004D77 0A                    2617 	.db 0x0a
      004D78 0D                    2618 	.db 0x0d
      004D79 20 25 70              2619 	.ascii " %p"
      004D7C 09                    2620 	.db 0x09
      004D7D 00                    2621 	.db 0x00
                                   2622 	.area CSEG    (CODE)
                                   2623 	.area CONST   (CODE)
      004D7E                       2624 ___str_25:
      004D7E 0A                    2625 	.db 0x0a
      004D7F 0D                    2626 	.db 0x0d
      004D80 25 70                 2627 	.ascii "%p"
      004D82 09                    2628 	.db 0x09
      004D83 00                    2629 	.db 0x00
                                   2630 	.area CSEG    (CODE)
                                   2631 	.area CONST   (CODE)
      004D84                       2632 ___str_26:
      004D84 25 58 20              2633 	.ascii "%X "
      004D87 00                    2634 	.db 0x00
                                   2635 	.area CSEG    (CODE)
                                   2636 	.area XINIT   (CODE)
      004D93                       2637 __xinit__gg:
      004D93 00                    2638 	.db #0x00	;  0
                                   2639 	.area CABS    (ABS,CODE)
