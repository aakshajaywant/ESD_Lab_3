/* ************************************************************************************************************************** */
/*                                  Author Name: Aaksha Jaywant                                                               */
/*                                 Course: Embedded System Design                                                             */
/*                                    Assignment: Lab 3 Part1                                                                */
/*        Leveraged Code: https://www.includehelp.com/c-programs/c-program-to-convert-ascii-to-integer.aspx                  */
/*                                                                                                                           */
/* ************************************************************************************************************************** */


#include <at89c51ed2.h>       //also includes 8052.h and 8051.h
#include <mcs51/mcs51reg.h>
#include <mcs51/8051.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#define DEBUG

#ifndef HEAP_SIZE
#define HEAP_SIZE 4000
#endif

//FOR DEBUG PORT
__xdata  __at (0xff01) uint8_t val;
#ifdef  DEBUG
#define DEBUGPORT(x) dataout(x); //((_xdata uint8_t *)0xFF01) = x;   // generates a  MOVX 0FFFFh,x where x is an 8-bit value
#else
#define DEBUGPORT(x)    // empty statement, nothing passed on from the preprocessor to the compiler
#endif

int dataout(uint8_t x)
{
   // uint8_t *ptr;
`   // ptr = 0xFF01;
    val = x;
    //int a = val;
    return 0;
}

__xdata char __sdcc_heap[HEAP_SIZE];
const unsigned int __sdcc_heap_size = HEAP_SIZE;

/* -------------------------------------------------- */
//          GLOBALS
/* -------------------------------------------------- */
// Note: A global variable like this is accessible anywhere in this file
//       What does volatile mean to the compiler?
volatile int8_t gg = 0;


/* -------------------------------------------------- */
//          FUNCTION DEFINITIONS
/* -------------------------------------------------- */
// Note: Generally functions should be declared and defined in files outside of main
//       e.g. in strfuncs.c and strfuncs.h . Here they are included in a single file
//       to make compilation of this example easier

_sdcc_external_startup()
{
// Note: Here is where you would put code to enable your internal RAM
//////    //       This code runs early in uC initialization and should be kept
//////    //       as small as possible. See section 4.1.4 of SDCC 3.9.0 Manual
    return 0;
}
//// Note: In a function file, each function should have a small explanation of its args and returns

// putchar takes a char and TX's it. Blocking. No return value.
int putchar (int c)
{
    // Note: Compare the asm generated for the next three lines
    //       They all accomplish the same thing, but is the asm the same?
    while (!TI);
    //while (TI == 0);
    //while ((SCON & 0x02) == 0);
     TI = 0;
    SBUF = c;           // load serial port with transmit value
             // clear TI flag

    return 1;
}

int getchar (void)
{
    // Note: Compare the asm generated for the next three lines
    //       They all accomplish the same thing, but is the asm the same?
    while (!RI);
    //while ((SCON & 0x01) == 0);
    //while (RI == 0);

    RI = 0;                         // clear RI flag
    return SBUF;                    // return character from SBUF
}


//global variables
uint8_t input_size;
char *temp0_ptr;
char ip_user;
uint8_t out_of_loop;
uint16_t count_forenter;

//FUNCTION FOR TAKING INPUT FROM THE USER
int buffer_input()
{
char b[10];
char *a;
a=b;
     for(uint8_t i=0;i<4;i++)
    {
        *(a+i) = getchar();
        putchar(*(a+i));

        if(*(a+i)== 0x0D)
        {
        count_forenter++;
        break;
        }
    }
input_size = atoi(a);
return input_size;
}



int main()
{
while(1)
{
    //ALL THE VARIABLES ALONG WITH THEIR DATA TYPES
    uint8_t buffer_size, buffer0_size;
    uint8_t *buff0_ptr, *buff1_ptr, *buff0_base, *save_start_to_buff0;
    uint8_t buffer_4comp=0;
    uint8_t arr_forfree_space[30];
    char arr_to_store[4000];
   // uint16_t buffn[30];
    uint8_t *buffptr_forplus[30];
    //buffptr_forplus = buffn;
    uint8_t count=2;
    uint16_t user_alpha=0;
    char valid_num;


/* ************************************************************************************************************************** */
/*                                               FOR ALLOCATING MEMORY SIZE TO BUFFER0                                        */
/*                                                                                                                            */
/* ************************************************************************************************************************** */

do
{
printf("Enter BUFFER size\n");
buffer_input(); //Allocating size to BUFFER 0
buffer_size = input_size;
buffer0_size= buffer_size; //saving the input buffer size into buffer0_size

printf("The BUFFER0 size entered by the user is %d\n",buffer_size);
} while((buffer_size%(16))!=0 || buffer_size<16 || buffer_size>3200);

// if(buffer0_size%16==0 && 32<=buffer0_size && buffer0_size<=3200)

buff0_ptr = (int *)malloc(buffer_size*sizeof(uint8_t)); //ALLOCATING BUFFER 0 ON THE HEAP

if(buffer_size>1984)       //BOUNDARY CHECK WHEN MALLOC WILL FAIL
{
    do
    {
    printf("Malloc Failed");
    free(buff0_ptr);
    printf("Enter value smaller than 1985bytes");
    buffer_input();
    buffer_size = input_size;
    buffer0_size = buffer_size; //saving buffer size in buffer0_size incase it enters this loop
    }while((buffer_size%(16))!=0 || buffer_size>1984);
    buff0_ptr = (int *)malloc(buffer_size*sizeof(uint8_t));
}


buff0_base=buff0_ptr;       //saving base pointer location of buffer0 into buff0_base

uint8_t buffer_op1 = buffer_size;


/* ************************************************************************************************************************** */
/*                                               FOR ALLOCATING MEMORY SIZE TO BUFFER1                                        */
/*                                                                                                                            */
/* ************************************************************************************************************************** */

//Allocating size to BUFFER 1
buff1_ptr = (int *)malloc(buffer_size*sizeof(uint8_t));

/* ************************************************************************************************************************** */
/*                                                  STORING CHARACTERS                                                        */
/*                                                                                                                            */
/* ************************************************************************************************************************** */


while(1)
{
//printf("\n\r****************************************************************************************************************\n");
//printf("\n\r SR NO.\t\t\t\t\t\tMENU \t\t\t\t\t\t\t\t\t\t\t\t\t\t\tPRESS\n\n\n");
//printf("\n\r\t 1)\t\t\t\t\t\t")
//printf("\n\r STORE LOWER \t\t\t\t\t|\t\t\t\t\t\t\t\t LOWERCASE ALPHABETS\n\n\n");
//printf("\n\r CASE CHARACTERS\t\t\t|\t\t\t\t")

printf("\n\rEnter character:");
ip_user=getchar();
putchar(ip_user);

    if(ip_user>='a' && ip_user<='z')
    {
    if(user_alpha<=buffer0_size)
    {
    count_forenter++;
    *buff0_ptr=ip_user;
    save_start_to_buff0 = buff0_base;
    arr_to_store[user_alpha]=ip_user; //store all the characters in a array
    user_alpha++;   //counter to track number of characters entered
   // buff0_ptr = (char*) temp0_ptr;
   // *temp0_ptr = ip_user;
    printf("\n\r Address:%p\t\t\t |\t\t\t %c",buff0_ptr,*buff0_ptr);
    buff0_ptr++;

    }
    else
        {

        printf("Extra characters on screen %c",ip_user);
        }

    }

/* ************************************************************************************************************************** */
/*                                                  ADDING MORE BUFFERS                                                       */
/*                                                                                                                            */
/* ************************************************************************************************************************** */

    else if(ip_user=='+')
        {

            do
            {
            count_forenter++;
            printf("\n\rEnter new buffer size between 30 to 300 bytes");
            buffer_input();
            buffer_size = input_size;
            arr_forfree_space[count] = buffer_size;
            buffer_4comp +=buffer_size;
            }while(buffer_size<30 || buffer_size>300);

            buffptr_forplus[count] = (int *)malloc(buffer_size*sizeof(uint8_t));
            printf("\n\r New buffer %d \t %p  \n",count,buffptr_forplus[count]);
           // buffn[count] = (int)buffptr_forplus;
           //(buffptr_forplus+buffer_size-1)++;
            count++;
            if(buffer_4comp>(4000-(2*buffer_op1)))
            {
            printf("Malloc Failed");
            free(buffptr_forplus);
            }
        }
/* ************************************************************************************************************************** */
/*                                                  REMOVING BUFFERS                                                          */
/*                                                                                                                            */
/* ************************************************************************************************************************** */

    else if(ip_user=='-')
        {
         count_forenter++;

            printf("\n\rEnter valid buffer number");
            buffer_input();
            valid_num = input_size;

        if(valid_num<=count)
        {
        printf("\n\rvalid number");
        free(buffptr_forplus[valid_num]);
        printf("\n\r%p \n",buffptr_forplus[valid_num]);
        buffptr_forplus[valid_num] = 0;
        }
        else
        {
        printf("\n\rInvalid number");
        }
        }
/* ************************************************************************************************************************** */
/*                                                  DISPLAYING HEAP INFO                                                      */
/*                                                                                                                            */
/* ************************************************************************************************************************** */

    else if(ip_user=='?')
        {
             DEBUGPORT(0x55);

            if(user_alpha<64)
            {
                count_forenter++;
                printf("\n\rThe total count is: %d",count_forenter);
                printf("\n\r Buffer0 Start Address %p",buff0_base);
                printf("\n\r Buffer0 End Address is %p",(buff0_base+buffer0_size));
                printf("\n\r Number of free spaces remaining in Buffer0 %d",((buffer0_size)-(user_alpha-1)));
                printf("\n\r Total allocated size of the buffer0 %d",buffer0_size);
                printf("\n\r Buffer1 Start Address %p",buff1_ptr);
                printf("\n\r Buffer1 End Address is %p",(buff1_ptr+(buffer0_size)));
                printf("\n\r Number of free spaces remaining in Buffer0 %d",buffer0_size);
                printf("\n\r Total allocated size of the buffer1 %d",buffer0_size);
                printf("\n\r Number of storage characters in the buffer0 %d",user_alpha);


             for(uint8_t i=2;i<=count;i++)
            {
            if(buffptr_forplus[i] !=0)
            {
            printf("\n\r Buffer %d Start Address %p",i,buffptr_forplus[i]);
            printf("\n\r Number of free spaces remaining in Buffer%d\t\t %d",i, arr_forfree_space[i]);
            }
            }



            for(uint8_t i=0;i<=user_alpha;i++)
            {
             printf("\n\r All the characters of an array are: %c", arr_to_store[i]);
            }
            }
           // }
            else if(user_alpha>=64)
            {

             for(uint8_t i=0;i<=user_alpha;i++)
             {
                buff0_ptr = NULL;
                //*buff0_ptr = '0';
                arr_to_store[i] = '0';
             }
             count_forenter++;
                printf("\n\rThe total count is: %d",count_forenter);
                printf("\n\r Buffer0 Start Address %p",buff0_base);
                printf("\n\r Buffer0 End Address is %p",(buff0_base+buffer0_size));
                printf("\n\r Number of free spaces remaining in Buffer0 %d",((buffer0_size)-(user_alpha-1)));
                printf("\n\r Total allocated size of the buffer0 %d",buffer0_size);
                printf("\n\r Buffer1 Start Address %p",buff1_ptr);
                printf("\n\r Buffer1 End Address is %p",(buff1_ptr+(buffer0_size)));
                printf("\n\r Number of free spaces remaining in Buffer0 %d",buffer0_size);
                printf("\n\r Total allocated size of the buffer1 %d",buffer0_size);
                printf("\n\r Number of storage characters in the buffer0 %d",user_alpha);

            for(uint8_t i=2;i<=count;i++)
            {
            if(buffptr_forplus[i] !=0)
            {
            printf("\n\r Buffer %d Start Address %p",i,buffptr_forplus[i]);
            printf("\n\r Number of free spaces remaining in Buffer%d\t\t %d",i, arr_forfree_space[i]);
            }
            }

            for(uint8_t i=0;i<=user_alpha;i++)
            {
            // printf("\n\r All the characters of an array are: %c", arr_to_store[i]);
            printf("\n\r All the characters of an array are: %c", arr_to_store[i]);
            }
            }


        }
/* ************************************************************************************************************************** */
/*                                                  DISPLAYING CHARACTERS                                                     */
/*                                                          ON SCREEN                                                         */
/* ************************************************************************************************************************** */

         else if(ip_user=='=')
        {

            printf("\n\r %p\t",save_start_to_buff0);


                   for(uint8_t i=0;i<=user_alpha;i++)
                    {

                            if(((i%16) == 0) && i != 0)
                            {
                            printf("\n\r%p\t",((save_start_to_buff0)+i));
                            }

                            printf("%X ",*(save_start_to_buff0+i));
                    }

        }


        else if(ip_user == '@')
        {
            free(buff0_base);
            free(buff1_ptr);
            for(uint8_t i=0;i<count;i++)
            {
               free(buffptr_forplus[count]);
            }
                break;
        }

}
}
return 0;
}














